<?php include"includes/admin_header.php"; ?>
<?php include "includes/dbconfig.php"; ?>

    <div id="wrapper">
        
        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            VIEW & EDIT ROUTES,
                            <small><?php echo ucfirst($_SESSION['s_username']); ?></small>
                        </h1>


                        <?php 

                        if (isset($_GET['source'])) {
                            $source = $_GET['source'];
                        }
                        else {
                            $source = "";
                        }

                        switch ($source) {
                            case 'update_route':
                                include "includes/update_route.php";
                                break;

                            default: ?>
                                <table class="table table-bordered table-hover"> 
                                <thead>
                                    <tr>
                                        <th>RouteId</th>
                                        <th>RouteName</th>
                                        <th>Source</th>
                                        <th>Destination</th>
                                        
                                        
                                    </tr>
                                </thead>

                                <tbody>
                                    
                                    <?php 
                                    

                                        $query = "SELECT *  FROM  routes";
                                        $select_route = mysqli_query($connection,$query);

                                        while($row = mysqli_fetch_assoc($select_route)) {
                                            $route_id = $row['RouteId'];
                                            $routename = $row['RouteName'];
                                            $source = $row['Source'];
                                            $destination = $row['Destination'];
                                                                                

                                     ?>
                                    <tr>
                                        <td><?php echo $route_id ?></td>
                                        <td><?php echo $routename ?></td>
                                        <td><?php echo $source ?></td>
                                        <td><?php echo $destination ?></td>
                                                                    
                                    
                                        <?php echo "<td><a href='routes.php?delete=$route_id'>Delete</a></td>"; ?>
                                        <?php echo "<td><a href='routes.php?source=update_route&route_id=$route_id'>Edit</a></td>"; ?>
                                        
                                    </tr>
                                    <?php } ?>
                                </tbody>
                                </table><?php
                                break;
                        }
                        
                        ?>

                        <?php 

                        if (isset($_GET['delete'])) {
                            
                            $route_idd = $_GET['delete'];
                            
                            $query = "DELETE FROM routes WHERE RouteId = {$route_idd} ";

                            $delete_query = mysqli_query($connection,$query);
                            
                            
                            
                        }

                        ?>

                       

                       
                    </div>
                </div>
                
            </div>

        </div>
        
<?php include"includes/admin_footer.php"; ?>