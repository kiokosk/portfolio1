<?php include "includes/dbconfig.php"; ?>
<?php include"includes/admin_header.php"; ?>

    <div id="wrapper">
        
        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           ADD NEW BUS(ES),
                            <small><?php echo ucfirst($_SESSION['s_username']); ?></small>
                        </h1>

                        <?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>
<?php 
	if (isset($_POST['insert-bus'])) {
		$psvid = $_POST['PsvId'];
		$psvname = $_POST['PsvName'];
		$routename = $_POST['RouteName'];
		$capacity = $_POST['capacity'];
		$date = $_POST['TDate'];
		$time = $_POST['TravelTime'];
		$scost = $_POST['SeatCost'];
		if ($psvname=="" || $routename=="" || $capacity=="" || $date=="" || $time=="" ) {
			echo "**Fill the mandatory fields";
		}
		else {
			$query = "INSERT INTO `psv`(`PsvId`, `PsvName`, `RouteName`, `capacity`, `TDate`, `TravelTime`, `SeatCost`) VALUES(NULL, '$psvname', '$routename', '$capacity', '$date', '$time', '$scost')";

			$bus_entry = mysqli_query($connection,$query);

			if (!$bus_entry) {
				die("Query Failed");
			}
			if($bus_entry) {
				echo '<p style="background-color:#66FFFF;">Bus added successfuly!</p>';
		
	
			}
		}
	}
	
?>


<form action="" method="post" enctype="multipart/form-data">
		<div class="form-group">
		<label for="psvid">PSV Id</label>
		<input type="text" class="form-control" name="PsvId" readonly >
	</div>
	<div class="form-group">
		<label for="pname">PSV Name</label>
		<input type="text" class="form-control" name="PsvName" required="">
	</div>
	<div class="form-group">
		<label for="rname">Route Name</label>
		<select name="RouteName" class="form-control" required>
		<?php $sqle = "SELECT * FROM `routes`";
    $routesselect1 = mysqli_query($connection,$sqle);
		while ($row1 = mysqli_fetch_assoc($routesselect1)) { ?>
		
		<option value="<?php echo $row1["RouteName"];?>" ><?php echo $row1["RouteName"];?></option>
        <?php } ?> </select>
		
	</div>
	<div class="form-group">
		<label for="capacity">PSV Capacity</label>
		<input type="text" class="form-control" name="capacity" required="">
		</div>
	<div class="form-group">
		<label for="tdate">Travel Date</label>
		<input type="date" style="margin-top: 10px;" min=<?php echo date('Y-m-d');?> max=<?php echo date('Y-m-d', strtotime(date('Y-m-d'). ' + 29 days'));?> name="TDate" class="form-control" id="date" placeholder="dd/mm/yyyy" required="">
		</div>
		<div class="form-group">
		<label for="ttime">Departure Time</label>
		<input type="time" class="form-control" name="TravelTime"  required="">
		</div>
	<div class="form-group">
		<label for="ttime">Cost per seat</label>
		<input type="number" class="form-control" name="SeatCost" placeholder="" required="">
		
	</div>
	<div class="form-group">
		<input type="submit" class="btn btn-primary" name="insert-bus" value="Add Bus">
	</div>
</form>
</div>
</div>
</div>




