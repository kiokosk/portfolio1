<?php include "includes/dbconfig.php"; ?>
<?php include"includes/admin_header.php"; ?>

    <div id="wrapper">
        
        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           ADD NEW ROUTE(S),
                            <small><?php echo ucfirst($_SESSION['s_username']); ?></small>
                        </h1>

                        <?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>

<?php 
                            if(isset($_POST['submit'])) {

                                $RouteId = $_POST['RouteId'];
                                $RouteName = $_POST['RouteName'];
                                $Source = $_POST['Source'];
                                $Destination = $_POST['Destination'];
                                if($RouteName==""|| $Source==""||$Destination==""){
                                    echo "*Fill the mandatory fields";
                                }else{
                                $query = "INSERT INTO `routes`(`RouteId`, `RouteName`, `Source`, `Destination`) VALUES (NULL,'$RouteName','$Source', '$Destination' )";
                                $create_route = mysqli_query($connection,$query);
                                
                                if(!$create_route) {
                                    die("Query Failed");
                                    
                                }
                                if($create_route) {
                                    echo '<p style="background-color:#66FFFF;">Route added successfuly!</p>';
                            
                        
                                }

                            }
                        }
                            ?>

                            <form action="" method="post">
                                <div class="form-group">
                                    <label for="cat_tite">Route Id</label>
                                    <input class="form-control" type="text" name="RouteId" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="cat_tite">Route Name</label>
                                    <input class="form-control" type="text" name="RouteName" required="">
                                </div>
                                <div class="form-group">
                                    <label for="cat_tite">Source</label>
                                    <input class="form-control" type="text" name="Source" required="">
                                </div>
                                <div class="form-group">
                                    <label for="cat_tite">Destination</label>
                                    <input class="form-control" type="text" name="Destination" required="">
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" name="submit" value="Add route">
                                </div> 
                            </form>
                        </div>
                        </div>
                        </div>