<?php include"includes/admin_header.php"; ?>
<?php include "includes/dbconfig.php";
 
require "boooking1.php";
?>

    <div id="wrapper">
        
        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           VIEW BOOKINGS,
                           <small><?php echo ucfirst($_SESSION['s_username']); ?></small>
                        </h1>
                       <!--first db connection-->
<?php

//error_reporting(0);
      
$mysqli_hostname = "localhost:3307";
$mysqli_user = "root";
$mysqli_password = "";
$mysqli_database = "bus_reservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>
<!--second db connection-->
<?php
//error_reporting(0);
      
$mysqli_hostname1 = "localhost";
$mysqli_user1 = "root";
$mysqli_pass = "TV180RC";
$mysqli_db = "busreservation";
$prefix = "";
$conn = mysqli_connect($mysqli_hostname1, $mysqli_user1, $mysqli_pass,$mysqli_db) or die("Could not connect database");
?>


                        <table class="table table-bordered table-hover"> 
                                <thead>
                                    <tr>
                                        <th>Passenger Name</th>
                                        <th>Telephone</th>
                                        <th>Source</th>
                                        <th>Destination</th>
                                        <th>Travel Date</th>
                                        <th>Travel Time</th>
                                        <th>PSV Id</th>
                                        <th>Seat Number</th>
                                        <th>Amount(Ksh.)</th>
                                        <th>Payment Status</th>                                                                              
                                    </tr>
                                </thead>

                                <tbody>
                                    <!--db1-->
                                    <?php 

                                        $query = "SELECT s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32  FROM  seats";
                                        $booking = mysqli_query($connection, $query);


                                    
                                        //db2 query
              $query3 = "SELECT* FROM passenger;";

              $pdetails = mysqli_query($conn, $query3);

              //db3
              $query1 = "SELECT id, Price_per_seat_ksh FROM seats ";

              $booking1 = mysqli_query($connection, $query1);

              while ($row = mysqli_fetch_assoc($pdetails)) {
                $fname = $row['fname'];
    $lname = $row['lname'];
    $telephone = $row['telephone'];
    $pickup = $row['pickup'];
    $destination = $row['destination'];
    $pdate = $row['pdate'];
    $ptime = $row['ptime'];
    $mins = $row['mins'];
    $det = $row['det'];
  
    

   
?>
                                        
   
                                       
                                     
                                    <tr>
                                        <td><?php echo $fname." ".$lname ?></td>
                                        <td><?php echo $telephone?></td>
                                        <td><?php echo $pickup ?></td>
                                        <td><?php echo $destination?></td>
                                        <td><?php echo $pdate?></td>
                                       <td><?php echo $ptime.":".$mins." ".$det?></td>
                                       
                                    <?php } ?>
                                    
                                    <?php
                                    while ($row = mysqli_fetch_assoc($booking1)) {
                                        $id = $row['id'];
                                        $price = $row['Price_per_seat_ksh']; ?>
                                        
                                     <?php
                                    } ?>            
              </tr>
                                </tbody>
                                </table><?php
                             
                        
                        ?>


                    </div>
                </div>
              
            </div>
           
        </div>
        
<?php include"includes/admin_footer.php"; ?>