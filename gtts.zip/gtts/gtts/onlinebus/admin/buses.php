<?php include"includes/admin_header.php"; ?>
<?php include "includes/dbconfig.php"; ?>


    <div id="wrapper">
        
        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            VIEW & EDIT PSVs,
                            <small><?php echo ucfirst($_SESSION['s_username']); ?></small>
                        </h1>
                        <?php 
                        if (isset($_GET['source'])) {
                            $source = $_GET['source'];
                        }
                        else {
                            $source = "";
                        }
                        switch ($source) {
                            case 'add_bus':
                                include "includes/add_bus.php";
                                break;
                            
                            case 'update':
                                include "includes/update.php";
                                break;

                            default: ?>
                                <table class="table table-bordered table-hover"> 
                                <thead>
                                    <tr>
                                        <th>PSV Id</th>
                                        <th>PSV Name</th>
                                        <th>Route Id</th>
                                        <th>Capacity</th>
                                        <th>Travel Date</th>
                                        <th>Departure Time</th>
                                        <th>Cost per seat</th>
                                        
                                                                               
                                    </tr>
                                </thead>

                                <tbody>
                                    
                                    <?php 

                                        $query = "SELECT *  FROM  psv";
                                        $select_psv = mysqli_query($connection,$query);

                                        while($row = mysqli_fetch_assoc($select_psv)) {
                                            $psv_id = $row['PsvId'];
                                            $psv_name = $row['PsvName'];
                                            $routeName = $row['RouteName'];
                                            $capacity = $row['capacity'];
                                            $date = $row['TDate'];
                                            $time = $row['TravelTime'];
                                            $scost = $row['SeatCost'];
                                            
                                        
                                        if ($date > date('Y-m-d')) {
                                            
                                        

                                     ?>
                                    <tr>
                                        <td><?php echo $psv_id ?></td>
                                        <td><?php echo $psv_name ?></td>
                                        <td><?php echo $routeName?></td>
                                        <td><?php echo $capacity?></td>
                                        <td><?php echo $date ?></td>
                                        <td><?php echo $time ?></td>
                                        <td><?php echo $scost ?></td>
                                        
                                        <?php echo "<td><a href='buses.php?delete=$psv_id'>Delete</a></td>"; ?>
                                        <?php echo "<td><a href='buses.php?source=update&psv_id=$psv_id'>Update</a></td>"; ?>
                                        
                                    </tr>
                                    <?php } }?>
                                </tbody>
                                </table><?php
                                break;
                        }
                        
                        ?>


                       

                        <?php 

                        if (isset($_GET['delete'])) {
                            
                            $bus_idd = $_GET['delete'];
                            
                            $query = "DELETE FROM psv WHERE PsvId = {$bus_idd} ";

                            $delete_bus = mysqli_query($connection,$query);
                            if(!$delete_bus) {
                                die("Query Failed"); //. mysqli_error($delete_bus));
                            }
                            header("Location: buses.php");
                        }

                        ?>


                    </div>
                </div>
                

            </div>
           
        </div>
        
<?php include"includes/admin_footer.php"; ?>