<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>admin</title>
</head>
<body  style="background-color:#FFCC66">
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background-color:blue; " >
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#FFCC66'" style=" font-weight:bold;color:#FFCC66" href="index.php">Bus Reservation System Admin</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li><a href="/gtts/gtts/index.html" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#FFCC66'" style=" font-weight:bold;color:#FFCC66">Home</a></li>
                
            
                <li class="dropdown">
                    <a href="#" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#FFCC66'" style=" font-weight:bold;color:#FFCC66;" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo ucfirst($_SESSION['s_username']); ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="../profile.php"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="../includes/logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav" style="background-color: #FFCC66;">
                    <li>
                        <a href="index.php" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold; font-size:large">
        <i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="javascript:;" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large"
         data-toggle="collapse" data-target="#demo1"><i class="fas fa -fw fa-road "aria-hidden="true"></i>
          Routes <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo1" class="collapse">
                            <li>
                                <a href="routes.php" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large">
        <i class="fa fa fa-fw fa-eye"></i></i>All routes </a>
                            </li>
                            <li>
                                <a href="addroute.php" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large">
        <i class="fa fa fa-fw fa-edit"></i></i>Add route </a>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large" data-toggle="collapse" data-target="#demo"><i class="fa fa fa-fw fa-bus" aria-hidden="true"></i>  Buses <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="buses.php"onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large"><i class="fa fa fa-fw fa-eye" aria-hidden="true"></i>All Buses</a>
                            </li>
                            <li>
                                <a href="addbus.php"onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large" ><i class="fa fa fa-fw fa-edit"></i>Add Buses</a>
                            </li>
                        </ul>
                    </li>
                    
                    <li>
                        <a href="./bookings.php"onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large" ><i class="fas fa-fw fa-ticket"></i> Bookings</a>
                    </li>
                    
                    <li>
                        <a href="../profile.php" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#006600'"style="color: #006600; font-weight:bold;font-size:large" ><i class="fa fa-fw fa-dashboard"></i> Profile</a>
                    </li>
                    
                </ul>
            </div>
            
        </nav>
        </body>
</html>