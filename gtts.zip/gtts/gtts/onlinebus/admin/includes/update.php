<?php include "includes/dbconfig.php"; ?>
<?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>

<?php 

if (isset($_GET['psv_id'])) {
	$edit_bus_id = $_GET['psv_id'];
}

$query = "SELECT *  FROM  psv WHERE PsvId=$edit_bus_id";
$select_psv = mysqli_query($connection,$query);

while($row = mysqli_fetch_assoc($select_psv)) {
    $psv_id = $row['PsvId'];
    $psvname = $row['PsvName'];
    $routename = $row['RouteName'];
    $capacity = $row['capacity'];
    $tdate = $row['TDate'];
    $ttime = $row['TravelTime'];
	$scost = $row['SeatCost'];

if (isset($_POST['update-bus'])) {
	$psv_id = $_POST['PsvId'];
    $psvname = $_POST['PsvName'];
    $routename = $_POST['RouteName'];
    $capacity = $_POST['capacity'];
    $tdate = $_POST['TDate'];
    $ttime =$_POST['TravelTime'];
	$scost =$_POST['SeatCost'];
	
	$query = "UPDATE psv SET PsvId='$psv_id',PsvName='$psvname', RouteName='$routename', capacity='$capacity', TDate='$tdate', 
	TravelTime='$ttime', SeatCost='$scost' WHERE PsvId=$edit_bus_id ";
		$update_bus = mysqli_query($connection,$query);
if (!$update_bus) {
		die("Query Failed" . mysqli_error($connection));
	}
	if($update_bus) {
		echo '<p style="background-color:#66FFFF;">Bus details updated successfuly!</p>';
	}
}
}
?>

<form action="" method="post" enctype="multipart/form-data">
	
<div class="form-group">
		<label for="psvid">PSV Id</label>
		<input value="<?php echo $psv_id; ?>" type="text" class="form-control" name="PsvId" readonly>
	</div>


	<div class="form-group">
		<label for="pname">PSV Name</label>
		<input value="<?php echo $psvname; ?>" type="text" class="form-control" name="PsvName" required="">
	</div>
	<div class="form-group">
		<label for="rname">Route Name</label>
		<input value="<?php echo $routename; ?>" type="text" class="form-control" name="RouteName" required="">
	</div>

	<div class="form-group">
		<label for="capacity">PSV Capacity</label>
		<input value="<?php echo $capacity; ?>" type="text" class="form-control" name="capacity" required="">
		
	</div>

	<div class="form-group">
		<label for="tdate">Travel Date</label>
		<input value="<?php echo $tdate; ?>" type="date" style="margin-top: 10px;" min=<?php echo date('Y-m-d');?> max=<?php echo date('Y-m-d', strtotime(date('Y-m-d'). ' + 29 days'));?> name="TDate" class="form-control" id="date" placeholder="dd/mm/yyyy" required="">
		
	</div>
	
	<div class="form-group">
		<label for="ttime">Departure Time</label>
		<input value="<?php echo $ttime; ?>" type="time" class="form-control" name="TravelTime" placeholder="Time in 12-hour clock system" required="">
		
	</div>
	<div class="form-group">
		<label for="tcost">Cost per seat</label>
		<input value="<?php echo $scost; ?>" type="number" class="form-control" name="SeatCost" placeholder="" required="">
		
	</div>



	<div class="form-group">
		<input type="submit" class="btn btn-primary" name="update-bus" value="Update">
	</div>
</form>
