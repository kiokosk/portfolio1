<?php include "includes/dbconfig.php"; ?>
<?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>

<?php

if (isset($_GET['route_id'])) {
	$edit_route_id = $_GET['route_id'];
}

$query = "SELECT *  FROM  routes WHERE RouteId=$edit_route_id";
$select_routes = mysqli_query($connection,$query);

while($row = mysqli_fetch_assoc($select_routes)) {
    $route_id = $row['RouteId'];
       $routename = $row['RouteName'];
          $source = $row['Source'];
          $destination = $row['Destination'];


if (isset($_POST['update-route'])) {
	
	$route_id = $_POST['RouteId'];
	$routename = $_POST['RouteName'];
	$source = $_POST['Source'];
	$destination = $_POST['Destination'];

	
	$query = "UPDATE routes SET RouteId = '$route_id', RouteName = '$routename' ,Source='$source', Destination='$destination' WHERE RouteId=$edit_route_id ";
		
	$update_route_detail = mysqli_query($connection,$query);

	if (!$update_route_detail) {
		die("Query Failed" . mysqli_error($connection));
	}
	if ($update_route_detail) {
		echo '<p style="background-color:#66FFFF;">Route details updated successfuly!</p>';
	}
}
}

?>

<form action="" method="post" enctype="multipart/form-data">
	
	<div class="form-group">
		<label for="route">Route Id</label>
		<input value="<?php echo $route_id; ?>" type="text" class="form-control"name="RouteId" readonly required="">
	</div>

	<div class="form-group">
		<label for="route">Route Name</label>
		<input value="<?php echo $routename; ?>" type="text" class="form-control" name="RouteName" required ="">
	</div>

	<div class="form-group">
		<label for="route">Source</label>
		<input value="<?php echo $source; ?>" type="text" class="form-control" name="Source" required="">
	</div>

	<div class="form-group">
		<label for="route">Destination</label>
		<input value="<?php echo $destination; ?>" type="text" class="form-control" name="Destination" required="">
	</div>
	<div class="form-group">
		<input type="submit" class="btn btn-primary" name="update-route" value="Update">
	</div>
</form>


