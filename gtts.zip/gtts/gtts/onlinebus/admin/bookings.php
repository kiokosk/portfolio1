<?php include"includes/admin_header.php"; ?>


    <div id="wrapper">
        
        <!-- Navigation -->
        <?php include"includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           VIEW BOOKINGS,
                           <small><?php echo ucfirst($_SESSION['s_username']); ?></small>
                        </h1>
                        <?php
$mysqli_hostname = "localhost:3307";
$mysqli_user = "root";
$mysqli_password = "";
$mysqli_database = "bus_reservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>


                        <table class="table table-bordered table-hover"> 
                                <thead>
                                    <tr>
                                        <th>Passenger Name</th>
                                        <th>Telephone</th>
                                        <th>Pickup location</th>
                                        <th>Destination</th>
                                        <th>Travel Date</th>
                                        <th>Travel Time</th>
                                        <th>Reservation Id</th>
                                        <th>Seat Number(s)</th>
                                        <th>Price per seat(Ksh)</th>
                                        <th>Number of seats</th>
                                        <th>Total Cost(Ksh.)</th>
                                        <th>Payment Status</th>                                                                              
                                    </tr>
                                </thead>

                                <tbody>
                                    
                                    <?php 

                                        $query = "SELECT *  FROM  booking";
                                        $bookings = mysqli_query($connection,$query);

                                        while($row = mysqli_fetch_assoc($bookings)) {
                                            $name = $row['name'];
                                            $telephone = $row['telephone'];
                                            $Source = $row['pickup'];
                                            $Destination = $row['destination'];
                                            $tDate = $row['tdate'];
                                            $Ttime = $row['ttime'];
                                            $bid = $row['b_id'];
                                            $sno = $row['snos'];
                                            $price = $row['Price_per_seat_ksh'];
                                            $no = $row['no'];
                                            $amount = $row['tcost'];
                                            $pstatus = $row['pstatus'];
                                       ?>
                                    <tr>
                                        <td><?php echo $name ?></td>
                                        <td><?php echo $telephone ?></td>
                                        <td><?php echo $Source ?></td>
                                        <td><?php echo $Destination?></td>
                                        <td><?php echo $tDate?></td>
                                        <td><?php echo $Ttime?></td>
                                        <td><?php echo $bid?></td>
                                        <td><?php echo $sno?></td>
                                        <td><?php echo $price?></td>
                                        <td><?php echo $no?></td>
                                        <td><?php echo $amount?></td>
                                        <td><?php echo $pstatus?></td>
                                      </tr>
                                    <?php } ?>
                                    </tbody>
                                </table><?php
                             
                        
                        ?>


                    </div>
                </div>
              
            </div>
           
        </div>
        
<?php include"includes/admin_footer.php"; ?>