<?php include"dbconfig.php" ?>
    <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color: #66FFCC;" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/gtts/gtts/index.html" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#000000'" style="font-size:x-large; font-weight:bold;color:black">Home</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    
                    
                </ul>
                <ul class="nav navbar-nav navbar-right">

                    <?php 
                    if(isset($_SESSION['s_username'])) {
                       
                            ?>
                            <li>
                                <a href="admin/index.php" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#000000'" style="font-size:x-large; font-weight:bold; color:black" ><i class="fa fa-fw fa-child"></i>Admin</a>
                            </li>
                    
                    <?php }  ?>

                    <li>
                        <a href="registration.php" onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#000000'" style="font-size:x-large; font-weight:bold;color:black"><i class="fa fa-user-plus" style="color:red"></i>Create Admin Account</a>
                    </li>


<!--
                    <?php 
                        if (isset($_SESSION['s_username'])) {
                            ?>
                            <li class="dropdown">
                                <a onMouseOver="this.style.color='white'"
        onMouseOut="this.style.color='#000000'" style="font-size:x-large; font-weight:bold;color:black" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php

                                if (isset($_SESSION['s_username'])) {
                                    echo ucfirst($_SESSION['s_username']);
                                } ?> <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="profile.php"><i class="fa fa-fw fa-user"></i> Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="includes/logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                                    </li>
                                </ul>
                            </li>
                            
                    <?php
                        }
                    ?>
                    -->

                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
