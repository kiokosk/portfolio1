<?php include "includes/dbconfig.php"; ?>
<?php include "includes/header.php"; ?>
    
    <!-- Navigation -->
    <?php include "includes/navigation.php"; ?>

<?php

if (isset($_POST['register'])) {
 
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
   

	$query = "INSERT INTO `admin_credentials`(`id`, `username`, `email`, `apassword`) VALUES(NULL, '$username', '$email', '$password')";


$register_user = mysqli_query($connection, $query);

if(!$register_user) {
    die("Query Failed" . mysqli_error($connection));
}

echo '<p style="background-color:green;color:white; text-align:center; font-size:xx-large">Account created successfuly!</p>';

}


?>

<!-- password style  -->   
<style>
/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "\2713";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "?";
}

</style>
    
<!-- endpassword style -->

    <div class="container">
        <div class="row">
            <div class="col-lg-6">
            <i class="fa fa-fw fa-user " style="margin-top: 10%;font-size:400px"></i>
            </div>
            <div class="col-lg-6" style="font-size:xx-large">
             <h2 style="margin-left: 30%; color:blue; font-weight:bold">Create an Admin Account</h2>
              <form action="" method="post" enctype="multipart/form-data">
               <div class="form-group">
                  <label for="email">Username:</label>
                  <input type="text" class="form-control" id="username" style="font-size: xx-large;height:max-content" placeholder="Enter Username" name="username"required="">
                </div>
               <div class="form-group">
                  <label for="email">Email:</label>
                  <input type="email" class="form-control" id="email" style="font-size: xx-large;height:max-content" placeholder="Enter email" name="email" required="">
                </div>
                <div class="form-group">
                  <label for="pwd">Password:</label>
                  <input type="password" class="form-control" id="pwd" name="password" style="font-size: xx-large;height:max-content" placeholder="Password" required
                  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"> 
                </div>
                <div class="form-group">
                  <label for="pwd"> Confirm Password:</label>
                  <input type="password" class="form-control" id="pwd2" name="confirm_password"
                   style="font-size: xx-large;height:max-content" placeholder="Reenter Password" required
                   pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"> 
                </div>
                        
                <button type="submit" class="btn btn-primary" name="register" style="margin-left: 40%; margin-top: 20px; font-size:xx-large;">Register</button>
              </form>
     <!--  password strength  -->     
<div id="message">
  <h3>Password must contain the following:</h3>
  <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
  <p id="capital" class="invalid">An <b>uppercase</b> letter</p>
  <p id="number" class="invalid">A <b>number</b></p>
  <p id="length" class="invalid">Minimum <b>8 characters</b></p>
</div>
				
<script>
var myInput = document.getElementById("pwd");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate uppercase letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
<!-- end password strength -->

<!-- confirm password backend-->
<script>
var password = document.getElementById("pwd")
  , confirm_password = document.getElementById("pwd2");

function validatePassword(){
  if(pwd.value != pwd2.value) {
    pwd2.setCustomValidity("Passwords Don't Match");
  } else {
    pwd2.setCustomValidity('');
  }
}

pwd.onchange = validatePassword;
pwd2.onkeyup = validatePassword;
</script>
<!-- end password confirmation -->
            </div>
        </div>

    </div>
        

