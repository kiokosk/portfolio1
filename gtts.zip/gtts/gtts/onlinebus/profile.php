<?php include "includes/dbconfig.php"; ?>
<?php include "includes/header.php";


 ?>
   <style>
     td{
       font-size: x-large;
     }
     .form-group{
       font-size: x-large;
     }
     .form-control{
       font-size: x-large;
     }
     input{
       font-size: x-large;
     }
   </style> 
    <!-- Navigation -->
    <?php include "includes/navigation.php"; ?>

    <!-- Page Content -->
    <!-- db -->
    <?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>

    <div class="container" style="width: 50%;">
                              
        <h2 style="margin-left: 40%;">Profile</h2>
               <i class="fa fa-fw fa-user " style="font-size: 200px; margin-left: 29%;"></i>
        <br>
        <div class="tab">
            <button class="tablinks" style="width: 33%" 
            onclick="openCity(event, 'Personal Details')">Personal Details</button>
            <button class="tablinks" style="width: 33%" 
             onclick="openCity(event, 'Edit Details')">Edit Details</button>
        </div>

        <div id="Personal Details" class="tabcontent">
          <h3> Personal Details</h3>
          <!-- <?php echo $_SESSION['s_id'];?> -->
          <br>
          <?php
          $curr_user_id = $_SESSION['s_id'];
          
          $query = "SELECT * FROM admin_credentials where id = $curr_user_id";

          $select_user = mysqli_query($connection, $query);

          while ($row = mysqli_fetch_assoc($select_user)) {
              $db_user_id = $row['id'];
              $db_username = $row['username'];
              $db_user_email = $row['email'];
              $db_user_password = $row['apassword']; ?>

            <table class="table table-striped" style="width: 50%">
              <tbody>
              <tr>
                  <td><b>Id:</b> </td>
                  <td><?php echo  $db_user_id; ?></td>
                </tr>
                <tr>
                  <td><b>Username:</b> </td>
                  <td><?php echo $db_username; ?></td>
                </tr>
                
              
                <tr>
                  <td><b>Email: </b></td>
                  <td><?php echo $db_user_email; ?></td>
                </tr>
                <tr>
                  <td><b>Password: </b></td>
                  <td><?php echo $db_user_password; ?></td>
                </tr>
                
              </tbody>
            </table>

          <?php
          } ?>
        
          </div> 

       
        <div id="Edit Details" class="tabcontent">
          <h3>Edit Details</h3>
          <br>
          <?php
            

            $curr_user_id = $_SESSION['s_id'];
            $query = "SELECT * FROM admin_credentials WHERE id = $curr_user_id ";
            $select_users = mysqli_query($connection,$query);

            while($row = mysqli_fetch_assoc($select_users)) {
              $db_user_id = $row['id'];
              $db_username = $row['username'];
              $db_user_email = $row['email'];
              $db_user_password = $row['apassword'];
            }

            if (isset($_POST['update-user'])) {
              // $user_id = $row['id'];
                $db_username = $_POST['username'];
                $db_user_email = $_POST['user_email'];
                $db_user_password = $_POST['user_password'];
                                            

                $query = "UPDATE admin_credentials SET username='{$db_username}', email='{$db_user_email}', apassword='{$db_user_password}' WHERE id=$curr_user_id";
              
                             
                $update_details = mysqli_query($connection, $query);

                if (!$update_details) {
                    die("Query Failed" . mysqli_error($connection));
                }
                
                echo '<p style="background-color:green;color:white; text-align:center; font-size:xx-large">Details successfully updated!</p>'; 
                //header("Location: profile.php");
                header("Location:profile.php");
            }

            ?>

            <form action="" method="post" enctype="multipart/form-data">
              
              <div class="form-group">
                <label for="username">Username</label>
                <input value="<?php echo $db_username; ?>" type="text" class="form-control" name="username">
              </div>
             
              <div class="form-group">
                <label for="email">Email</label>
                <input value="<?php echo $db_user_email; ?>" type="email" class="form-control" name="user_email">
              </div>

             
              <div class="form-group">
                <label for="password">Password</label>
                <input value="<?php echo $db_user_password?>" id="myInput" type="password" class="form-control" name="user_password">
              </div>

              <div class="form-group">
                <input type="checkbox" onclick="myFunction()" style="height: 20px; width:20px">Show Password
              </div>

                           
              <div class="form-group">
                <input type="submit" class="btn btn-primary" style="font-size: x-large;" name="update-user" value="Update">
              </div>
            </form>


        </div>

    </div>
        <hr>


        <script>

    function myFunction() {
        var x = document.getElementById("myInput");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }


    function openCity(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
    }
    </script>

<?php include "../onlinebus/admin/includes/admin_footer.php"; ?> 