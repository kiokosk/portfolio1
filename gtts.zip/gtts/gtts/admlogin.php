<html>
    <head>
        <title>adminlogin
        </title>
    <!--styles for the login-->
        <link rel="stylesheet" href="css/admlogin.css" />
</head>
<body style="background-color:#FFFFCC" >
<?php
    session_start();
    include('dbconfig.php');
    
if (isset($_POST['loginsubmit']) || isset($_POST['register'])) {
	//echo "hello";
	$username = $_POST['username'];
	$password = $_POST['password'];

	$query = "SELECT * FROM admin_credentials WHERE username = '$username'";
	$select_user = mysqli_query($connection,$query);

	if (!$select_user) {
		die("Query Failed" . mysqli_error($connection));
	}

	while ($row = mysqli_fetch_assoc($select_user)) {
		$db_user_id = $row['id'];
		$db_username = $row['username'];
        $db_user_email = $row['email'];
		$db_user_password = $row['apassword'];
		

		if($username === $db_username && $password === $db_user_password) {      
			$_SESSION['s_username'] = $db_username;
			$_SESSION['s_email'] = $db_user_email;
            $_SESSION['s_password'] = $db_user_password;
            $_SESSION['s_id'] = $db_user_id;
            header("Location: /gtts/gtts/onlinebus/admin/index.php");	
        }
        elseif ($username !== $db_username && $password !== $db_user_password){
            
            echo  '<p style="background-color:#FF0000; font-size:large; color:white;">
            Invalid username or password!</p>';
        }
        else{        
            echo  '<p style="background-color:#FF0000; font-size:large; color:white;">
            Invalid username or password!</p>';
        }
    }

}

if(!empty($_POST["rememberme"])) {
	setcookie ("username",$_POST["username"],time()+ 3600);
	setcookie ("password",$_POST["password"],time()+ 3600);
	echo "Credentials set to be remembered";
} else {
	setcookie("username","");
	setcookie("password","");
	
}

?>
<div>
<img src="images/logos/glogo.png" alt="logo" width="200px;" />
<h1 style="color:#000066"> GTTS Admin</h1>
<form method="post" action="" name="signin-form">
  <div class="form-element">
  <h2 class="h3 mb-3 font-weight-normal text-muted text-center">Login to your Account</h2><br><br>

<div class="text-center mb-3">
    <small class="text-success font-weight-bold">
        <?php
            if (isset($_SESSION['STATUS']['loginstatus']))
                echo $_SESSION['STATUS']['loginstatus'];

        ?>
    </small>
</div>

<div class="form-group">
    
    <un >Username:</un><input type="text" id="username" name="username" class="form-control" value="<?php if(isset($_COOKIE["username"])) { echo $_COOKIE["username"]; } ?>" placeholder="Username" required autofocus><br><br>
    <sub class="text-danger">
        <?php
            if (isset($_SESSION['ERRORS']['nouser']))
                echo $_SESSION['ERRORS']['nouser'];
        ?>
    </sub>
</div>

<div class="form-group">
<pw>Password:</pw> <input type="password" id="password" name="password" class="form-control" value="<?php if(isset($_COOKIE["password"])) { echo $_COOKIE["password"]; } ?>" placeholder="Password" required><br><br>
    <sub class="text-danger">
        <?php
            if (isset($_SESSION['ERRORS']['wrongpassword']))
                echo $_SESSION['ERRORS']['wrongpassword'];
        ?>
    </sub>
</div>

<div class="col-auto my-1 mb-4">
    <div class="custom-control custom-checkbox mr-sm-2">
        <input type="checkbox" class="custom-control-input" id="rememberme" name="rememberme">
        <label class="custom-control-label" for="rememberme">Remember me</label><br>
    </div>
</div>

<button class="btn btn-lg btn-primary btn-block" type="submit" value="loginsubmit" name="loginsubmit">  Login</button><br><br>

<p class="mt-3 text-muted text-center"><a href="#" style="text-decoration: none;">Forgot password?</a></p>
  </div>
</form></body>
</html>
