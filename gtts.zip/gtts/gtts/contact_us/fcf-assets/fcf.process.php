<?php


require dirname(__FILE__).'/'.'fcf.config.php';
require dirname(__FILE__).'/'.'process.php';