<?php include('../dbconfig.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>booknow</title>
    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="css/style.css" />

</head>

<body>
   
    <div id="booking" class="section">
        <div class="section-center">
            <div class="container">
                <div class="row">
                    <div class="booking-form">
                        <div class="form-header">
                            <h1>welcome to gtts</h1>
                            <h2>Make your bookings!</h2>
                           
                            
                        </div>
                        <form action="used.php" method ="post" enctype="multipart/form-data">
                        <h2 class="h3 font-weight-bold text-center" style="color: blue; font-weight:bold">Kindly fill in the details</h2>
                        <span class="form-label">Full Name</span>
                            <div class="row">

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <span class="sub-label">Firstname</span>
                                        <input class="form-control" type="text" onkeydown="return /[a-z]/i.test(event.key)"
                                         placeholder="Enter firstname" name="fname" required="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <span class="sub-label">Lastname</span>
                                        <input class="form-control" type="text" onkeydown="return /[a-z]/i.test(event.key)"
                                         placeholder="Enter your lastname" name="lname" required="">
                                    </div>
                                </div>
                            </div>
                    
                            <div class="form-group">
                                <span class="form-label">Phone</span>
                                <input class="form-control" type="tel" name="telephone"  pattern="[0]{1}[0-9]{9}" title="Please enter valid phone number(10 digits)" placeholder="0712345678" required="">
                            </div>
                            <div class="form-group">
                                <span class="form-label">Pickup Location</span>
                                
<?php $sql = "SELECT * FROM `routes`";
    $all_routes = mysqli_query($connection,$sql);
       ?>
          <select class="form-control" name="pickup" required>
                 <option selected="true" disabled="disabled">Select pickup location</option>
                                                  <?php  while ($row = mysqli_fetch_assoc($all_routes)) { ?>
													<option value="<?php echo $row["Source"];?>" ><?php echo $row["Source"];?></option>
                                                    <?php } ?>
												
													</select>
                            </div>
                            <?php $sql = "SELECT * FROM `routes`";
    $all_routes = mysqli_query($connection,$sql);
   
    ?>
                            <div class="form-group">
                                <span class="form-label">Destination</span>
                                
                                <select class="form-control" name="destination" required>
                                                    <option selected="true" disabled="disabled"><small>Select destination</small></option>
                                                    <?php  while ($row1 = mysqli_fetch_assoc($all_routes)) { ?>
													<option value="<?php echo $row1["Destination"];?>" ><?php echo $row1["Destination"];?></option>
                                                    <?php } ?>
													</select>
                            </div>
               
                            <div class="row">
                                <div class="col-sm-5">
                                    <div class="form-group">
                                        <span class="form-label">Travel Date</span>
                                        <input class="form-control" type="date" name="pdate"  min=<?php echo date('Y-m-d');?> max=<?php echo date('Y-m-d', strtotime(date('Y-m-d'). ' + 29 days'));?> required>
										
                                    </div>
                                </div>
                                <div class="col-sm-7">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <span class="form-label">Hour</span>
                                                <select class="form-control" name="ptime">
													<option value="5">5</option>
													<option value="7">7</option>
													<option value="9">9</option>
													<option value="11">11</option>
													
												</select>
                                                
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <span class="form-label">Min</span>
                                                <select class="form-control" name="mins">
													<option value="00">00</option>
													<option value="15">15</option>
													<option value="30">30</option>
													<option value="45">45</option>
													
												</select>
                                                
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="form-group">
                                                <span class="form-label">AM/PM</span>
                                                <select class="form-control" name="det">
                                                   
													<option value="AM">AM</option>
													<option value="PM">PM</option>
												</select>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-btn">
                                <input type="submit" class="submit-btn" name="Submit"  value="proceed"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
