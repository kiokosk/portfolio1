<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Complete booking</title>

<style>

    @media print {
  /* style sheet for print goes here */
  .noprint{  display:none; }
}
body {
    text-align: center;
	background-color:#6EB43F;
}
.container {
    display: inline-block;
    
}
table{
      
  margin-left: auto;
  margin-right: auto;
  display: inline-block;
 background-image: url(bg.tiff);
}
form{
margin-top:70px;}
span:after {
    content: " , ";
}
span:last-child:after {
    content: " ";
}
b, td{
font-size: x-large;
margin-left:auto ;
margin-right: auto;
text-align: justify;
padding-right:20px;

}
.btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited {
    background-color: blue ;
    color: white;
    font-size: x-large;
}
</style>
<!-- bootstrap -->
<link rel="stylesheet" href="gtts/gtts/bootstrap-5.0.1-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="gtts/gtts/bootstrap-5.0.1-dist/js/bootstrap.min.js" />

</head>

<body>
  <!--print button-->
  

<div class="container">

<!--first db connection-->
<?php

 //error_reporting(0);
       
$mysqli_hostname = "localhost:3307";
$mysqli_user = "root";
$mysqli_password = "";
$mysqli_database = "bus_reservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>
<!--second db connection-->
<?php
 //error_reporting(0);
       
$mysqli_hostname1 = "localhost";
$mysqli_user1 = "root";
$mysqli_pass = "TV180RC";
$mysqli_db = "busreservation";
$prefix = "";
$conn = mysqli_connect($mysqli_hostname1, $mysqli_user1, $mysqli_pass,$mysqli_db) or die("Could not connect database");
?>

<?php
         
         if (isset($_POST['Submit'])) {
          
          date_default_timezone_set('Africa/Nairobi');
        
          # access token
          $consumerKey = 'qGrZcmDqP9A925q3vpzNWWZBjeG3HbYc'; //Fill with your app Consumer Key
          $consumerSecret = 'sGpEmzZqfrNYgmS5'; // Fill with your app Secret
        
          
          $BusinessShortCode = '174379';
          $Passkey = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';  
          
         
          
          $PartyA =$_POST['phone']; // This is your phone number, 
          $AccountReference =$_POST['nname'];
          $TransactionDesc = 'test';
          $Amount = $_POST['amount'];
         
          # Get the timestamp, format YYYYmmddhms -> 20181004151020
          $Timestamp = date('YmdHis');    
          
          # Get the base64 encoded string -> $password. The passkey is the M-PESA Public Key
          $Password = base64_encode($BusinessShortCode.$Passkey.$Timestamp);
        
          # header for access token
          $headers = ['Content-Type:application/json; charset=utf8'];
        
            # M-PESA endpoint urls
          $access_token_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
          $initiate_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
        
          # callback url
          $CallBackURL = 'https://mydomain.com/path';  
        
          $curl = curl_init($access_token_url);
          curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
          curl_setopt($curl, CURLOPT_HEADER, FALSE);
          curl_setopt($curl, CURLOPT_USERPWD, $consumerKey.':'.$consumerSecret);
          $result = curl_exec($curl);
          $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
          $result = json_decode($result);
          $access_token = $result->access_token;  
          curl_close($curl);
        
          # header for stk push
          $stkheader = ['Content-Type:application/json','Authorization:Bearer '.$access_token];
        
          # initiating the transaction
          $curl = curl_init();
          curl_setopt($curl, CURLOPT_URL, $initiate_url);
          curl_setopt($curl, CURLOPT_HTTPHEADER, $stkheader); //setting custom header
        
          $curl_post_data = array(
            //Fill in the request parameters with valid values
            'BusinessShortCode' => $BusinessShortCode,
            'Password' => $Password,
            'Timestamp' => $Timestamp,
            'TransactionType' => 'CustomerPayBillOnline',
            'Amount' => $Amount,
            'PartyA' => $PartyA,
            'PartyB' => $BusinessShortCode,
            'PhoneNumber' => $PartyA,
            'CallBackURL' => $CallBackURL,
            'AccountReference' => $AccountReference,
            'TransactionDesc' => $TransactionDesc
          );
        
          $data_string = json_encode($curl_post_data);
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($curl, CURLOPT_POST, true);
          curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
          $curl_response = curl_exec($curl);
          print_r($curl_response);
        
          echo $curl_response;
          header("Location: blank.html");
        //response save
        $stkCallbackResponse = file_get_contents('php://input');
        $logFile = "stkPushCallbackResponse.txt";
        $log = fopen($logFile, "a");
        fwrite($log, $stkCallbackResponse);
        fclose($log);
      
        
         }

          if (isset($_POST['view'])) {
              $query = "SELECT s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32 FROM seats ORDER BY id DESC LIMIT 1 ;";

              $booking = mysqli_query($connection, $query);

             
              //db2 query
              $query3 = "SELECT* FROM passenger ORDER BY id DESC LIMIT 1 ;";

              $pdetails = mysqli_query($conn, $query3);

              while ($row = mysqli_fetch_assoc($pdetails)) {
                $fname = $row['fname'];
    $lname = $row['lname'];
    
    $telephone = $row['telephone'];
    $pickup = $row['pickup'];
    $destination = $row['destination'];
    $tdate = $row['pdate'];
    $ptime = $row['ptime'];
    $mins = $row['mins'];
    $det = $row['det'];
?>
  <table class="table " style="width: 90%">
              <tbody>
              <div style="text-align: center;">
              <tr>
                  <td><b></b> </td>
                  <td class="noprint"  style="padding-left: 160%;"> <input style="font-size: pdatelarge;" type="button" onclick="window.print()" value="Print Receipt" /> </td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
            </tr>
            <!--
                <tr >

                  <td style="padding-left:250px;"><b><img src="glogo.png" alt="logo" width="100px;"/></b></td>
                  <td></td>
              </tr>-->
              <tr style="padding-left:50px;">               
                    <td><img src="glogo.png" alt="logo" width="100px;"/></td>
                    <td><?php echo  '<b style="background-color:#6666CC;color:#33FFCC;">RECEIPT</b>';?></td>
            </tr>
              <tr >
                  <td ><b></b></td>
                  <td  ><?php echo  '<b style="background-color:#6666CC; color:#33FFCC;">GRAND TOURS TRANSPORT SACCO</b>';?></td>
              </tr>
              
              </div>
              <tr>
                  <td><b>Full Name:</b> </td>
                  <?php $name= $fname." "." ".$lname; ?>
                  <td><?php echo $fname." "." ".$lname; ?></td>
                </tr>
                <tr>
                  <td><b>Telephone:</b> </td>
                  <td><?php echo $telephone; ?></td>
                </tr>
                <tr >
                  <td><b>Pickup location:</b> </td>
                  <td><?php   echo $pickup; ?></td>
                </tr>
                <tr >
                  <td><b>Destination:</b> </td>
                  <td><?php   echo $destination; ?></td>
                </tr>
                <tr >
                  <td><b>Travel Date:</b> </td>
                  <td><?php   echo $tdate; ?></td>
                </tr>
                <tr >
                  <td><b>Travel Time:</b> </td>
                  <?php $ttime= $ptime.":".$mins." ".$det; ?>
                  <td><?php   echo $ptime.":".$mins." ".$det; ?></td>
                </tr>
                </tbody>
            </table>
<?php 
}

 while ($row = mysqli_fetch_assoc($booking)) {
                 
                 $s1 = $row['s1'];
                 $s2 = $row['s2'];
                 $s3 = $row['s3'];
                 $s4 = $row['s4'];
                 $s5 = $row['s5'];
                 $s6 = $row['s6'];
                 $s7 = $row['s7'];
                 $s8 = $row['s8'];
                 $s9 = $row['s9'];
                 $s10 = $row['s10'];
                 $s11 = $row['s11'];
                 $s12= $row['s12'];
                 $s13= $row['s13'];
                 $s14= $row['s14'];
                 $s15= $row['s15'];
                 $s16= $row['s16'];
                 $s17= $row['s17'];
                 $s18= $row['s18'];
                 $s19= $row['s19'];
                 $s20= $row['s20'];

                 $s21= $row['s21'];
                 $s22 = $row['s22'];
                 $s23= $row['s23'];
                 $s24 = $row['s24'];
                 $s25 = $row['s25'];
                 $s26 = $row['s26'];
                 $s27 = $row['s27'];
                 $s28 = $row['s28'];
                 $s29 = $row['s29'];
                 $s30 = $row['s30'];
                 $s31 = $row['s31'];
                 $s32 = $row['s32'];
                  ?>
               

           <table class="table" style="width: 90%">
             <tbody>
            
               <tr>
                 <td><b>Seat Numbers:</b> </td>
                 <td><?php
                 $count = 0;
                 
               foreach ($row as $value) {
                   if (!$value=="") {
                     $seats1[]=$value;

                           $count = $count + 1;
                      
                   }
               }
              $seats= implode(", ", $seats1);
              echo $seats;
              
                ?></td>
                                  
               </tr>
                                           
             </tbody>
           </table>
           
           <?php
             }
             ?>

              <!--db2 query-->
             
<?php
              $query1 = "SELECT id, Price_per_seat_ksh FROM seats ORDER BY id DESC LIMIT 1 ;";

              $booking1 = mysqli_query($connection, $query1);
              while ($row = mysqli_fetch_assoc($booking1)) {
                  $id = $row['id'];
                  $price = $row['Price_per_seat_ksh']; ?>
                  <table class="table" style="width: 90%">
              <tbody>
            
              <tr>
                  <td><b>Booking Id:</b> </td>
                  <td><?php echo $id; ?></td>
                </tr>
                <tr>
                  <td><b>Cost per seat (Ksh.):</b> </td>
                  <td><?php echo $price; ?></td>
                </tr>
                <tr style="text-decoration:overline;">
                  <td><b>TOTAL COST(KSH):</b> </td>
                  <td><?php
                  $total=$price*$count;
                   echo $total; ?></td>
                </tr>
                <tr >
                  <td><b>Payment status:</b> </td>
                  <?php $pstatus="Unpaid"; ?>
                  <td><?php echo '<b style="background-color:red;color:white;">Unpaid!</b>';?></td>
                </tr>
                
                <tr >
                  <td><b></b> </td>
                  <td></td>
                </tr>
                <tr >
                  <td><b></b> </td>
                  <td><?php echo '<b style="color:green">THANK YOU FOR CHOOSING US!</b>';?></td>
                </tr>
                <tr >
                  <td><b></b> </td>
                  <td><?php echo '<b style="color:green"> Comfortable| Safe | Fast </b>';?></td>
                </tr>
                <tr >
                  <td><b></b> </td>
                  <td><?php echo '<b style="color:green">GTTS Kenya&copy;
                        <script>
                            document.write(new Date().getFullYear());
                        </script></b>';?></td>
                </tr>
               
                </tbody>
            </table>
                <?php
              }
              $query4 = "INSERT INTO `booking`(`name`,`telephone`,`pickup`,`destination`,`tdate`,`ttime`,`b_id`,`snos`,`Price_per_seat_ksh`,`no`,`tcost`, `pstatus` 
              )
                VALUES('$name','$telephone','$pickup','$destination','$tdate','$ttime','$id','$seats','$price', '$count','$total' ,'$pstatus')";
                         $save_seat = mysqli_query($connection,$query4);
                    if (!$save_seat) {
               				echo mysqli_error($connection);
              }
                    else {
                        echo '<p style="background-color:#66FFFF;">Saved successfuly!</p>';
                        }
          }
          ?>





</div>
</body>
</html>
