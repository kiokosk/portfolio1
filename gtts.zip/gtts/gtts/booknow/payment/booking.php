<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Complete booking</title>

<style>

    @media print {
  /* style sheet for print goes here */
  .noprint{  display:none; }
}
body {
    text-align: center;
	background-color:#6EB43F;
}
.container {
    display: inline-block;
    
}
table{
      
  margin-left: auto;
  margin-right: auto;
  display: inline-block;
 background-image: url(bg.tiff);
}
form{
margin-top:70px;}
span:after {
    content: " , ";
}
span:last-child:after {
    content: " ";
}
b, td{
font-size: x-large;
margin-left:auto ;
margin-right: auto;
text-align: justify;
padding-right:20px;

}
.btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited {
    background-color: blue ;
    color: white;
    font-size: x-large;
}
</style>
<!-- bootstrap -->
<link rel="stylesheet" href="gtts/gtts/bootstrap-5.0.1-dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="gtts/gtts/bootstrap-5.0.1-dist/js/bootstrap.min.js" />

</head>

<body>
  <!--print button-->
  

<div class="container">

<!--first db connection-->
<?php

 //error_reporting(0);
       
$mysqli_hostname = "localhost:3307";
$mysqli_user = "root";
$mysqli_password = "";
$mysqli_database = "bus_reservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>
<!--second db connection-->
<?php
 //error_reporting(0);
       
$mysqli_hostname1 = "localhost";
$mysqli_user1 = "root";
$mysqli_pass = "TV180RC";
$mysqli_db = "busreservation";
$prefix = "";
$conn = mysqli_connect($mysqli_hostname1, $mysqli_user1, $mysqli_pass,$mysqli_db) or die("Could not connect database");
?>

<?php
         

          if (isset($_POST['view'])) {
              $query = "SELECT s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32 FROM seats ORDER BY id DESC LIMIT 1 ;";

              $booking = mysqli_query($connection, $query);

             
              //db2 query
              $query3 = "SELECT* FROM passenger ORDER BY id DESC LIMIT 1 ;";

              $pdetails = mysqli_query($conn, $query3);

              while ($row = mysqli_fetch_assoc($pdetails)) {
                $fname = $row['fname'];
    $lname = $row['lname'];
    
    $telephone = $row['telephone'];
    $pickup = $row['pickup'];
    $destination = $row['destination'];
    $pdate = $row['pdate'];
    $ptime = $row['ptime'];
    $mins = $row['mins'];
    $det = $row['det'];
?>
  <table class="table " style="width: 90%">
              <tbody>
              <div style="text-align: center;">
              <tr>
                  <td><b></b> </td>
                  <td class="noprint"  style="padding-left: 160%;"> <input style="font-size: large;" type="button" onclick="window.print()" value="Print Receipt" /> </td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
            </tr>
            <!--
                <tr >

                  <td style="padding-left:250px;"><b><img src="glogo.png" alt="logo" width="100px;"/></b></td>
                  <td></td>
              </tr>-->
              <tr style="padding-left:50px;">
                   
                    <td><img src="glogo.png" alt="logo" width="100px;"/></td>
                    <td><?php echo  '<b style="background-color:#6666CC;color:#33FFCC;">RECEIPT</b>';?></td>
            </tr>
              <tr >

                  <td ><b></b></td>
                  <td  ><?php echo  '<b style="background-color:#6666CC; color:#33FFCC;">GRAND TOURS TRANSPORT SACCO</b>';?></td>
              </tr>
              
              </div>
              <tr>
                  <td><b>Full Name:</b> </td>
                  <td><?php echo $fname." "." ".$lname; ?></td>
                </tr>
                <tr>
                  <td><b>Telephone:</b> </td>
                  <td><?php echo $telephone; ?></td>
                </tr>
                <tr >
                  <td><b>Pickup location:</b> </td>
                  <td><?php   echo $pickup; ?></td>
                </tr>
                <tr >
                  <td><b>Destination:</b> </td>
                  <td><?php   echo $destination; ?></td>
                </tr>
                <tr >
                  <td><b>Travel Date:</b> </td>
                  <td><?php   echo $pdate; ?></td>
                </tr>
                <tr >
                  <td><b>Travel Time:</b> </td>
                  <td><?php   echo $ptime.":".$mins." ".$det; ?></td>
                </tr>
                </tbody>
            </table>
<?php 
}

 while ($row = mysqli_fetch_assoc($booking)) {
                 
                 $s1 = $row['s1'];
                 $s2 = $row['s2'];
                 $s3 = $row['s3'];
                 $s4 = $row['s4'];
                 $s5 = $row['s5'];
                 $s6 = $row['s6'];
                 $s7 = $row['s7'];
                 $s8 = $row['s8'];
                 $s9 = $row['s9'];
                 $s10 = $row['s10'];
                 $s11 = $row['s11'];
                 $s12= $row['s12'];
                 $s13= $row['s13'];
                 $s14= $row['s14'];
                 $s15= $row['s15'];
                 $s16= $row['s16'];
                 $s17= $row['s17'];
                 $s18= $row['s18'];
                 $s19= $row['s19'];
                 $s20= $row['s20'];

                 $s21= $row['s21'];
                 $s22 = $row['s22'];
                 $s23= $row['s23'];
                 $s24 = $row['s24'];
                 $s25 = $row['s25'];
                 $s26 = $row['s26'];
                 $s27 = $row['s27'];
                 $s28 = $row['s28'];
                 $s29 = $row['s29'];
                 $s30 = $row['s30'];
                 $s31 = $row['s31'];
                 $s32 = $row['s32'];
                  ?>
               

           <table class="table" style="width: 90%">
             <tbody>
            
               <tr>
                 <td><b>Seat Numbers:</b> </td>
                 <td><?php
                 $count = 0;
               foreach ($row as $value) {
                   if (!$value=="") {
                       
                           echo "<span>" . $value."</span>" ;
                           $count = $count + 1;
                           
                   }
               }   
              
                ?></td>
                                  
               </tr>
                                           
             </tbody>
           </table>
           
           <?php
             }
             ?>

              <!--db2 query-->
             
<?php
              $query1 = "SELECT id, Price_per_seat_ksh FROM seats ORDER BY id DESC LIMIT 1 ;";

              $booking1 = mysqli_query($connection, $query1);
              while ($row = mysqli_fetch_assoc($booking1)) {
                  $id = $row['id'];
                  $price = $row['Price_per_seat_ksh']; ?>
                  <table class="table" style="width: 90%">
              <tbody>
            
              <tr>
                  <td><b>Booking Id:</b> </td>
                  <td><?php echo $id; ?></td>
                </tr>
                <tr>
                  <td><b>Cost per seat (Ksh.):</b> </td>
                  <td><?php echo $price; ?></td>
                </tr>
                <tr style="text-decoration:overline;">
                  <td><b>TOTAL COST(KSH):</b> </td>
                  <td><?php
                  $total=$price*$count;
                   echo $total; ?></td>
                </tr>
                <tr >
                  <td><b>Payment status:</b> </td>
                  <td><?php echo '<b style="background-color:red;color:white;">Unpaid!</b>';?></td>
                </tr>
                
                <tr >
                  <td><b></b> </td>
                  <td></td>
                </tr>
                <tr >
                  <td><b></b> </td>
                  <td><?php echo '<b style="color:green">THANK YOU FOR CHOOSING US!</b>';?></td>
                </tr>
                <tr >
                  <td><b></b> </td>
                  <td><?php echo '<b style="color:green">Comfortable| Safe | Fast </b>';?></td>
                </tr>
                <tr >
                  <td><b></b> </td>
                  <td><?php echo '<b style="color:green">GTTS Kenya&copy;
                        <script>
                            document.write(new Date().getFullYear());
                        </script></b>';?></td>
                </tr>
               
                </tbody>
            </table>
                <?php
              }
          }
          ?>





</div>
</body>
</html>
