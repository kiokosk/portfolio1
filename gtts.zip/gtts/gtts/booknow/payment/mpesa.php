<!DOCTYPE html>
<html>
<?php /* require '../seats/seat.php' */?>
<head>
    <title>Complete booking</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <marquee style="background-color:#00CC99; font-size:x-large; color:#FFFFFF"> Final step!</marquee>
    <h2 align="center"> Make your your payment to complete your booking</h2>
    <img class="wave" src="img/wave.png">
    <div class="container">
        <div class="img">
            <img src="img/mpesa.tiff" height="120px" style="padding-left:5px; padding-bottom:5px">
        </div>
        <div class="login-content">
            <form action="boooking1.php" method="post">

                <h2 class="title">LIPA NA MPESA</h2>
                <div class="input-div one">
                    <div class="i">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="div">
                        <h5>Name</h5>
                        <input type="text" class="input" onkeydown="return /[a-z]/i.test(event.key)" 
                        name="nname" required>
                    </div>
                </div>
                <div class="input-div pass">
                    <div class="i">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                    </div>
                    <div class="div">
                        <h5>Phone</h5>
                        <input type="tel" class="input" 
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" maxlength="12"
                         name="phone" required>
                    </div>
                </div>
                <div class="input-div pass">
                    <div class="i">
                        <i class="fa fa-money" aria-hidden="true"></i>
                    </div>
                    <div class="div">
                        <h5>Amount(Ksh)</h5>
                        <input type="number" value="1000" class="input"
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');"
                        name="amount" required>
                    </div>
                </div>
                </br>
                <input type="submit" class="btn" value="check out" name="Submit">
                <input type="submit" class="btn" value="view bookings" name="view">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>