<?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>

<?php 

	if (isset($_POST['Submit'])) {
		
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    
    $telephone = $_POST['telephone'];
    $pickup = $_POST['pickup'];
    $destination = $_POST['destination'];
    $pdate = $_POST['pdate'];
    $ptime = $_POST['ptime'];
    $mins = $_POST['mins'];
    $det = $_POST['det'];
    
    if($fname=="" || $lname=="" ||$telephone=="" || $pickup==""|| $destination==""||$pdate==""||$ptime==""||$mins==""||$det==""){
        echo "*Fill all the mandatory fields";
    }
   
    else{
    $query = "INSERT INTO `passenger`(`id`,`fname`,`lname`, `telephone`, `pickup`, `destination`, `pdate`, `ptime`,`mins`,`det`) VALUES (NULL,'$fname','$lname','$telephone','$pickup','$destination' ,'$pdate','$ptime','$mins','$det')";
    $submit_detail = mysqli_query($connection,$query);
    
    if(!$submit_detail) {
        die("Query Failed");
        
   }
   if($submit_detail) {
    header("Location: seats/seat.php");

}}
}


?>