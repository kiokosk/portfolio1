
<?php
$mysqli_hostnam = "localhost";
$mysqli_user1 = "root";
$mysqli_passd = "TV180RC";
$mysqli_database1 = "busreservation";
$prefix = "";
$connectionr = mysqli_connect($mysqli_hostnam, $mysqli_user1, $mysqli_passd,$mysqli_database1) or die("Could not connect database");
?>
<?php $sql = "SELECT * FROM `psv`";
    $all_psvs = mysqli_query($connectionr,$sql);
       ?>
<?php 
 $mysqli_hostname = "localhost:3307";
 $mysqli_user = "root";
 $mysqli_password = "";
 $mysqli_database = "bus_reservation";
 $prefix = "";
//  $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
//  //$sqls1 = "SELECT s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32 FROM seats where Price_per_seat_ksh = '1000'";
//  $sqls1 = "SELECT s3 FROM seats where Price_per_seat_ksh = '1000' and s3 = '3'";
 
//  $cols1 = mysqli_query($connectionq,$sqls1); 
//  $row11 = mysqli_fetch_assoc($cols1);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="style.css" type="text/css"/>
    <title>seats selection</title>
    <style>
#seats{
    display: none;
}
</style> 
</head>
<body>
<?php
 error_reporting(0);     
$mysqli_hostname = "localhost:3307";
$mysqli_user = "root";
$mysqli_password = "";
$mysqli_database = "bus_reservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>
<?php 

if (isset($_POST['submit-selection'])) {
	
		$price = $_POST['psvid'];
		$s1 = $_POST['s1'];
		$s2 = $_POST['s2'];
		$s3 = $_POST['s3'];
        $s4 = $_POST['s4'];
		$s5 = $_POST['s5'];
        $s6 = $_POST['s6'];
		$s7 = $_POST['s7'];
        $s8 = $_POST['s8'];
		$s9 = $_POST['s9'];
        $s10 = $_POST['s10'];
		$s11 = $_POST['s11'];
        $s12= $_POST['s12'];
		$s13= $_POST['s13'];
        $s14= $_POST['s14'];
		$s15= $_POST['s15'];
        $s16= $_POST['s16'];
		$s17= $_POST['s17'];
        $s18= $_POST['s18'];
		$s19= $_POST['s19'];
        $s20= $_POST['s20'];
		$s21= $_POST['s21'];
        $s22 = $_POST['s22'];
		$s23= $_POST['s23'];
        $s24 = $_POST['s24'];
		$s25 = $_POST['s25'];
        $s26 = $_POST['s26'];
		$s27 = $_POST['s27'];
        $s28 = $_POST['s28'];
		$s29 = $_POST['s29'];
        $s30 = $_POST['s30'];
		$s31 = $_POST['s31'];
        $s32 = $_POST['s32'];
        if ($s1=="" &&  $s2==""&&$s3=="" && $s4=="" &&  $s5==""&& $s6=="" &&  $s7==""&&$s8=="" && $s9=="" &&  $s10==""&& $s11=="" &&  $s12==""&&$s13=="" && $s14=="" &&  $s15==""&& $s16=="" &&  $s17==""&&$s18=="" && $s19=="" &&  $s20==""&& $s21=="" &&  $s22==""&&$s23=="" && $s24=="" &&  $s25==""&& $s26=="" &&  $s27==""&&$s28=="" && $s29=="" &&  $s30==""&& $s31=="" &&  $s32=="" ) {
			echo  '<p style="background-color:#FF0000;">SELECT AT LEAST A SEAT!</p>';
		}
       
        else {
            $query = "INSERT INTO `seats`(`id`,`Price_per_seat_ksh`, `s1`, `s2`, `s3`, `s4`, `s5`, `s6`, `s7`, `s8`, `s9`, `s10`, `s11`, `s12`, `s13`, `s14`, `s15`, `s16`, `s17`, `s18`, `s19`, `s20`, `s21`, `s22`, `s23`, `s24`, `s25`, `s26`, `s27`, `s28`, `s29`, `s30`, `s31`, `s32`) VALUES(NULL,'$price', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7', '$s8', '$s9', '$s10', '$s11', '$s12', '$s13', '$s14', '$s15', '$s16', '$s17', '$s18', '$s19', '$s20', '$s21', '$s22', '$s23', '$s24', '$s25', '$s26', '$s27', '$s28', '$s29', '$s30', '$s31', '$s32')";
           
			$save_seat = mysqli_query($connection,$query);
            if (!$save_seat) {
				die("Query Failed");
			}
            else {

				echo '<p style="background-color:#66FFFF;">Seat selected successfuly!</p>';
                header("Location: /gtts/gtts/booknow/payment/mpesa.php");

		    }
			
        }
	}

?>

<form method="post" action="">
    <div class="movie-container">
   
        <label >Select your preferred bus:</label>
        <select id="movie" name="psvid">
       <?php while ($row1 = mysqli_fetch_assoc($all_psvs)) { ?>
		<option value="<?php echo $row1["SeatCost"];?>" ><?php echo $row1["PsvName"];?></option>
        <?php } ?> 
      
      </select>
    
    </div>

    <ul class="showcase">
        <li>
            <div class="seat"></div>
            Available
        </li>
        <li>
            <div class="seat selected"></div>
            Selected
        </li>
        <li>
            <div class="seat occupied"></div>
            Booked
        </li>
    </ul>
    
    
        
    <?php
 error_reporting(0);
       

?>
  <?php
  
       ?>

    <div class="container">
        <div class="screen">

        </div>
        
        <div class="row">
           
           <label class="row1"><input type="checkbox" name="s4" id="seats" value="4" /><div class="<?php 
          
          $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         //$sqls1 = "SELECT s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31,s32 FROM seats where Price_per_seat_ksh = '1000'";
         $sqls4 = "SELECT s4, Price_per_seat_ksh FROM seats";
         
         $cols4 = mysqli_query($connectionq,$sqls4); 
         
        while ($row14 = mysqli_fetch_assoc($cols4)) {
                $set4 = $row14['s4'];
                $p4 = $row14['Price_per_seat_ksh'];
                       if(!$set4 ==""){
                           echo"seat occupied";
                          
                       }
                       elseif($p4 =="" ){
                        echo "seat";    
                       }
                      
                       else{
                           echo "seat"; 
                       
                       }
                   }
         
              ?>">4</div></label>
           <label ><input type="checkbox" name="s3" id="seats" value="3" /><div class="<?php 
          $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
          $sqls1 = "SELECT s3, Price_per_seat_ksh FROM seats";
          $cols1 = mysqli_query($connectionq,$sqls1); 
          while ($row11 = mysqli_fetch_assoc($cols1)) {
            $set = $row11['s3'];
                 $p = $row11['Price_per_seat_ksh'];
                        if(!$set ==""){
                            echo"seat occupied";
                        }
                        else{
                            echo "seat"; 
                        }
                    }        
              ?>">3</div></label>
           <label class="row1"><input type="checkbox" name="s2" id="seats" value="2" /><div class="<?php  
         $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
        
         $sqls2 = "SELECT s2, Price_per_seat_ksh FROM seats ";
         
         $cols2 = mysqli_query($connectionq,$sqls2); 
         
        while ($row12 = mysqli_fetch_assoc($cols2)) {
                $set1 = $row12['s2'];
                $p1 = $row12['Price_per_seat_ksh'];
                       if(!$set1 ==""){
                           echo"seat occupied";
                          
                       }
                       else{
                           echo "seat"; 
                       
                       }
                   }
      
              ?>">2</div></label>
          
    <label ><input type="checkbox" name="s1" id="seats" value="1" /><div class="<?php 
        /*  $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
         $sqls01 = "SELECT s1, Price_per_seat_ksh FROM seats "; 
         
      $cols01 = mysqli_query($connectionq,$sqls01); 
         
        while ($row01 = mysqli_fetch_assoc($cols01)) {&
                $set01 = $row01['s1'];
                $p01 = $row01['Price_per_seat_ksh'];
                       if(!$set01 =="" && $p01=="1000" ){
                           echo"seat occupied";
                       }
                       else{
                           echo "seat"; 
                       
                      }
                   }  */
                   echo "seat occupied";
                         ?>">1</div></label> 
          
         
       </div>

       <div class="row">
<label class="row1"><input type="checkbox" name="s8" id="seats" value="8" /><div class="<?php 
          $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
          $sqls08 = "SELECT s8, Price_per_seat_ksh FROM seats";
          
          $cols08 = mysqli_query($connectionq,$sqls08); 
          
         while ($row08 = mysqli_fetch_assoc($cols08)) {
                 $set08 = $row08['s8'];
                 $p08 = $row08['Price_per_seat_ksh'];
                        if(!$set08 =="" ){
                            echo"seat occupied";
                        }
                        else{
                            echo "seat"; 
                        
                        }
                    }
           
              ?>">8</div></label>
<label ><input type="checkbox" name="s7" id="seats" value="7" /><div class="<?php 
          $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
          $sqls07 = "SELECT s7, Price_per_seat_ksh FROM seats";
          
          $cols07 = mysqli_query($connectionq,$sqls07); 
          
         while ($row07 = mysqli_fetch_assoc($cols07)) {
                 $set07 = $row07['s7'];
                 $p07 = $row07['Price_per_seat_ksh'];
                        if(!$set07 ==""){
                            echo"seat occupied";
                        }
                        else{
                            echo "seat"; 
                        
                        }
                    }
              ?>">7</div></label>
<label class="row1"><input type="checkbox" name="s6" id="seats" value="6" /><div class="<?php 
          
          $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
          $sqls06 = "SELECT s6, Price_per_seat_ksh FROM seats";
          
          $cols06 = mysqli_query($connectionq,$sqls06); 
          
         while ($row06 = mysqli_fetch_assoc($cols06)) {
                 $set06 = $row06['s6'];
                 $p06 = $row06['Price_per_seat_ksh'];
                        if(!$set06 =="" ){
                            echo"seat occupied";
                        }
                        else{
                            echo "seat"; 
                        
                        }
                    }
         
              ?>">6</div></label>
<label> <input type="checkbox" name="s5" id="seats" value="5" /><div class="<?php 
          
          $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
          $sqls05 = "SELECT s5, Price_per_seat_ksh FROM seats ";
          
          $cols05 = mysqli_query($connectionq,$sqls05); 
          
         while ($row05 = mysqli_fetch_assoc($cols05)) {
                 $set05 = $row05['s5'];
                 $p05 = $row05['Price_per_seat_ksh'];
                        if(!$set05 ==""){
                            echo"seat occupied";
                        }
                        else{
                            echo "seat"; 
                        
                        }
                    }
              ?>">5</div></label>

       </div>
       <div class="row">
       <label class="row1"><input type="checkbox" name="s12" id="seats" value="12" /><div class="<?php 
      $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
      $sqls012 = "SELECT s12, Price_per_seat_ksh FROM seats";
      
      $cols012 = mysqli_query($connectionq,$sqls012); 
      
     while ($row012 = mysqli_fetch_assoc($cols012)) {
             $set012 = $row012['s12'];
             $p012 = $row012['Price_per_seat_ksh'];
                    if(!$set012 ==""){
                        echo"seat occupied";
                    }
                    else{
                        echo "seat"; 
                    
                    }
                }
              ?>">12</div></label>
       <label><input type="checkbox" name="s11" id="seats" value="11" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls011 = "SELECT s11, Price_per_seat_ksh FROM seats ";
        
        $cols011 = mysqli_query($connectionq,$sqls011); 
        
       while ($row011 = mysqli_fetch_assoc($cols011)) {
               $set011 = $row011['s11'];
               $p011 = $row011['Price_per_seat_ksh'];
                      if(!$set011 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">11</div></label>
       <label class="row1"><input type="checkbox" name="s10" id="seats" value="10" /><div class="<?php 
      $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
      $sqls010 = "SELECT s10,  Price_per_seat_ksh FROM seats";
      
      $cols010 = mysqli_query($connectionq,$sqls010); 
      
     while ($row010 = mysqli_fetch_assoc($cols010)) {
             $set010 = $row010['s10'];
             $p010 = $row010['Price_per_seat_ksh'];
                    if(!$set010 =="" ){
                        echo"seat occupied";
                    }
                    else{
                        echo "seat"; 
                    
                    }
                }
              ?>">10</div></label>
        <!--<label><input type="checkbox" name="s9" id="seats" value="9" /><div class="seat occupied">9</div></label>-->
        <label><input type="checkbox" name="s9" id="seats" value="9" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls09 = "SELECT s9, Price_per_seat_ksh FROM seats ";
        
        $cols09 = mysqli_query($connectionq,$sqls09); 
        
       while ($row09 = mysqli_fetch_assoc($cols09)) {
               $set09 = $row09['s9'];
               $p09 = $row09['Price_per_seat_ksh'];
                      if(!$set09 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">9</div></label>


       </div>
       <div class="row">
       <label class="row1"><input type="checkbox" name="s16" id="seats" value="16" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls016 = "SELECT s16, Price_per_seat_ksh FROM seats";
        
        $cols016 = mysqli_query($connectionq,$sqls016); 
        
       while ($row016 = mysqli_fetch_assoc($cols016)) {
               $set016 = $row016['s16'];
               $p016 = $row016['Price_per_seat_ksh'];
                      if(!$set016 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">16</div></label>
       <label ><input type="checkbox" name="s15" id="seats" value="15" /><div class="<?php 
         $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
         $sqls015 = "SELECT s15, Price_per_seat_ksh FROM seats ";
         
         $cols015 = mysqli_query($connectionq,$sqls015); 
         
        while ($row015 = mysqli_fetch_assoc($cols015)) {
                $set015 = $row015['s15'];
                $p015 = $row015['Price_per_seat_ksh'];
                       if(!$set015 =="" ){
                           echo"seat occupied";
                       }
                       else{
                           echo "seat"; 
                       
                       }
                   }
              ?>">15</div></label>
       <label class="row1"><input type="checkbox" name="s14" id="seats" value="14" /><div class="<?php 
       $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
       $sqls014 = "SELECT s14, Price_per_seat_ksh FROM seats ";
       
       $cols014 = mysqli_query($connectionq,$sqls014); 
       
      while ($row014 = mysqli_fetch_assoc($cols014)) {
              $set014 = $row014['s14'];
              $p014 = $row014['Price_per_seat_ksh'];
                     if(!$set014 ==""){
                         echo"seat occupied";
                     }
                     else{
                         echo "seat"; 
                     
                     }
                 }
              ?>">14</div></label>
       <label ><input type="checkbox" name="s13" id="seats" value="13" /><div class="<?php 
         $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
         $sqls013 = "SELECT s13, Price_per_seat_ksh FROM seats";
         
         $cols013 = mysqli_query($connectionq,$sqls013); 
         
        while ($row013 = mysqli_fetch_assoc($cols013)) {
                $set013 = $row013['s13'];
                $p013 = $row013['Price_per_seat_ksh'];
                       if(!$set013 ==""){
                           echo"seat occupied";
                       }
                       else{
                           echo "seat"; 
                       
                       }
                   }
              ?>">13</div></label>

       </div>
       <div class="row">
       <label class="row1"><input type="checkbox" name="s20" id="seats" value="20" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls020 = "SELECT s20, Price_per_seat_ksh FROM seats";
        
        $cols020 = mysqli_query($connectionq,$sqls020); 
        
       while ($row020 = mysqli_fetch_assoc($cols020)) {
               $set020 = $row020['s20'];
               $p020 = $row020['Price_per_seat_ksh'];
                      if(!$set020 =="" ){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">20</div></label>
       <label><input type="checkbox" name="s19" id="seats" value="19" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls019 = "SELECT s19, Price_per_seat_ksh FROM seats ";
        
        $cols019 = mysqli_query($connectionq,$sqls019); 
        
       while ($row019 = mysqli_fetch_assoc($cols019)) {
               $set019 = $row019['s19'];
               $p019 = $row019['Price_per_seat_ksh'];
                      if(!$set019 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">19</div></label>
       <label class="row1"><input type="checkbox" name="s18" id="seats" value="18" /><div class="<?php 
         $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
         $sqls018 = "SELECT s18, Price_per_seat_ksh FROM seats";
         
         $cols018 = mysqli_query($connectionq,$sqls018); 
         
        while ($row018 = mysqli_fetch_assoc($cols018)) {
                $set018 = $row018['s18'];
                $p018 = $row018['Price_per_seat_ksh'];
                       if(!$set018 =="" ){
                           echo"seat occupied";
                       }
                       else{
                           echo "seat"; 
                       
                       }
                   }
              ?>">18</div></label>
       <label><input type="checkbox" name="s17" id="seats" value="17" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls017 = "SELECT s17, Price_per_seat_ksh FROM seats ";
        
        $cols017 = mysqli_query($connectionq,$sqls017); 
        
       while ($row017 = mysqli_fetch_assoc($cols017)) {
               $set017 = $row017['s17'];
               $p017 = $row017['Price_per_seat_ksh'];
                      if(!$set017 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">17</div></label>

       </div>
       <div class="row">
       <label class="row1"><input type="checkbox" name="s24" id="seats" value="24" /><div class="<?php 
         $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
         $sqls024 = "SELECT s24, Price_per_seat_ksh FROM seats ";
         
         $cols024 = mysqli_query($connectionq,$sqls024); 
         
        while ($row024 = mysqli_fetch_assoc($cols024)) {
                $set024 = $row024['s24'];
                $p024 = $row024['Price_per_seat_ksh'];
                       if(!$set024 ==""){
                           echo"seat occupied";
                       }
                       else{
                           echo "seat"; 
                       
                       }
                   }
              ?>">24</div></label>
       <label><input type="checkbox" name="s23" id="seats" value="23" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls023 = "SELECT s23, Price_per_seat_ksh FROM seats ";
        
        $cols023 = mysqli_query($connectionq,$sqls023); 
        
       while ($row023 = mysqli_fetch_assoc($cols023)) {
               $set023 = $row023['s23'];
               $p023 = $row023['Price_per_seat_ksh'];
                      if(!$set023 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">23</div></label>
       <label class="row1"><input type="checkbox" name="s22" id="seats" value="22" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls022 = "SELECT s22, Price_per_seat_ksh FROM seats ";
        
        $cols022 = mysqli_query($connectionq,$sqls022); 
        
       while ($row022 = mysqli_fetch_assoc($cols022)) {
               $set022 = $row022['s22'];
               $p022 = $row022['Price_per_seat_ksh'];
                      if(!$set022 =="" ){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">22</div></label>
       <!--<label><input type="checkbox" name="s21" id="seats" value="21" /><div class="seat occupied">21</div></label>-->
       <label><input type="checkbox" name="s21" id="seats" value="21" /><div class="<?php 
      $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
      $sqls021 = "SELECT s21, Price_per_seat_ksh FROM seats ";
      
      $cols021 = mysqli_query($connectionq,$sqls021); 
      
     while ($row021 = mysqli_fetch_assoc($cols021)) {
             $set021 = $row021['s21'];
             $p021 = $row021['Price_per_seat_ksh'];
                    if(!$set021 =="" ){
                        echo"seat occupied";
                    }
                    else{
                        echo "seat"; 
                    
                    }
                }
              ?>">21</div></label>

       </div>
       <div class="row">
       <label class="row1"><input type="checkbox" name="s28" id="seats" value="28" /><div class="<?php 
         $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
         $sqls028 = "SELECT s28, Price_per_seat_ksh FROM seats ";
         
         $cols028 = mysqli_query($connectionq,$sqls028); 
         
        while ($row028 = mysqli_fetch_assoc($cols028)) {
                $set028 = $row028['s28'];
                $p028 = $row028['Price_per_seat_ksh'];
                       if(!$set028 =="" ){
                           echo"seat occupied";
                       }
                       else{
                           echo "seat"; 
                       
                       }
                   }
              ?>">28</div></label>
       <label><input type="checkbox" name="s27" id="seats" value="27" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls027 = "SELECT s27, Price_per_seat_ksh FROM seats ";
        
        $cols027 = mysqli_query($connectionq,$sqls027); 
        
       while ($row027 = mysqli_fetch_assoc($cols027)) {
               $set027 = $row027['s27'];
               $p027 = $row027['Price_per_seat_ksh'];
                      if(!$set027 =="" ){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">27</div></label>
       <label class="row1"><input type="checkbox" name="s26" id="seats" value="26" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls026 = "SELECT s26, Price_per_seat_ksh FROM seats";
        
        $cols026 = mysqli_query($connectionq,$sqls026); 
        
       while ($row026 = mysqli_fetch_assoc($cols026)) {
               $set026 = $row026['s26'];
               $p026 = $row026['Price_per_seat_ksh'];
                      if(!$set026 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">26</div></label>
       <label ><input type="checkbox" name="s25" id="seats" value="25" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls025 = "SELECT s25, Price_per_seat_ksh FROM seats ";
        
        $cols025 = mysqli_query($connectionq,$sqls025); 
        
       while ($row025 = mysqli_fetch_assoc($cols025)) {
               $set025 = $row025['s25'];
               $p025 = $row025['Price_per_seat_ksh'];
                      if(!$set025 =="" ){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">25</div></label>
       </div>
       <div class="row">
       <label class="row1"><input type="checkbox" name="s32" id="seats" value="32" /><div class="<?php 
       $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
       $sqls032 = "SELECT s32, Price_per_seat_ksh FROM seats ";
       
       $cols032 = mysqli_query($connectionq,$sqls032); 
       
      while ($row032 = mysqli_fetch_assoc($cols032)) {
              $set032 = $row032['s32'];
              $p032 = $row032['Price_per_seat_ksh'];
                     if(!$set032 ==""){
                         echo"seat occupied";
                     }
                     else{
                         echo "seat"; 
                     
                     }
                 }
              ?>">32</div></label>
       <label ><input type="checkbox" name="s31" id="seats" value="31" /><div class="<?php 
        $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
        $sqls031 = "SELECT s31, Price_per_seat_ksh FROM seats ";
        
        $cols031 = mysqli_query($connectionq,$sqls031); 
        
       while ($row031 = mysqli_fetch_assoc($cols031)) {
               $set031 = $row031['s31'];
               $p031 = $row031['Price_per_seat_ksh'];
                      if(!$set031 ==""){
                          echo"seat occupied";
                      }
                      else{
                          echo "seat"; 
                      
                      }
                  }
              ?>">31</div></label>
       <label class="row1"><input type="checkbox" name="s30" id="seats" value="30" /><div class="<?php 
       $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
       $sqls030 = "SELECT s30, Price_per_seat_ksh FROM seats ";
       
       $cols030 = mysqli_query($connectionq,$sqls030); 
       
      while ($row030 = mysqli_fetch_assoc($cols030)) {
              $set030 = $row030['s30'];
              $p030 = $row030['Price_per_seat_ksh'];
                     if(!$set030 ==""){
                         echo"seat occupied";
                     }
                     else{
                         echo "seat"; 
                     
                     }
                 }
              ?>">30</div></label>
       <label ><input type="checkbox" name="s29" id="seats" value="29" /><div class="<?php 
      $connectionq = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
         
      $sqls029 = "SELECT s29, Price_per_seat_ksh FROM seats";
      
      $cols029 = mysqli_query($connectionq,$sqls029); 
      
     while ($row029 = mysqli_fetch_assoc($cols029)) {
             $set029 = $row029['s29'];
             $p029 = $row029['Price_per_seat_ksh'];
                    if(!$set029 ==""){
                        echo"seat occupied";
                    }
                    else{
                        echo "seat"; 
                    
                    }
                }
              ?>">29</div></label>
       </div>
       
   </div>
    
    <p class="text">
        You have selected <span id="count">0</span> seats for a price of Ksh. <span id="total">0</span
    >&nbsp;
  </p>
  <div style="padding-left: 220px;padding-top: 30px;"><input type="submit" style="font-size: x-large;" class="btn btn-primary"  name="submit-selection" value="Submit"></div>
  </form>
  <script src="script.js"></script>
</body>
</html>