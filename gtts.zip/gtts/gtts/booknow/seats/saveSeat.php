<?php
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>

<?php 

	if (isset($_POST['submit-selection'])) {
		
		$psvid = $_POST['PsvId'];
        $sno = $_POST['SeatNumber'];
		$sno1=$annArray[0];
        $sno2=$annArray[1];
        $sno3=$annArray[2];
		$avail = $_POST['availability'];
		
        $lsData = isset($_POST['submit-selection'])?$_POST['submit-selection']:'';
        $annArray = json_decode($lsData, true);
        
        $annArray = json_decode(json_encode($lsData, true), true);
        $countArray = count($annArray);
        $interval = $countArray/3;
        
        
        function fill_chunck($array, $parts) {
            $t = 0;
            $result = array_fill(0, $parts - 1, array());
            $max = ceil(count($array) / $parts);
            foreach($array as $v) {
                count($result[$t]) >= $max and $t ++;
                $result[$t][] = $v;
            }
            return $result;
        }
        
        //echo print_r(fill_chunck($annArray, $interval));
        $inputArray = [];
        $inputArray = fill_chunck($annArray, $interval);
        
        foreach($inputArray as $value=>$data) {
            $sno1 = $data[0];
            $sno2 = $data[1];
            $sno3 = $data[2];
            $sno4 = $data[3];
            $sno5 = $data[4];
            $sno6 = $data[5];
            $sno7 = $data[6];
            $sno8 = $data[7];
            $sno9 = $data[8];
            $sno10 = $data[9];
            $sno11 = $data[10];
            $sno12 = $data[11];
            $sno13= $data[12];
            $sno14 = $data[13];
            $sno15 = $data[14];
            $sno16 = $data[15];
            $sno17 = $data[16];
            $sno18 = $data[17];
            $sno19 = $data[18];
            $sno20 = $data[19];
            $sno21 = $data[20];
            $sno22 = $data[21];
            $sno23 = $data[22];
            $sno24 = $data[23];
            $sno25 = $data[24];
            $sno26 = $data[25];
            $sno27 = $data[26];
            $sno28 = $data[27];
            $sno29 = $data[28];
            $sno30 = $data[29];  
            $sno31 = $data[30];
            $sno32 = $data[31];
            
           
        
            $sql = "INSERT into `annotations` (`imagename`, `locationName`, `brandname`, `firstx`, `firsty`, `secondx`,`secondy`, `thirdx`,`thirdy`) values 
                ('$image', '$location','$brand','$firstX','$firstY','$secondX','$secondY','$thirdX','$thirdY');";
        
        
            $result = mysqli_query($connect, $sql) or die(mysqli_error($connect));
            if ($result) {
                echo "Data uploaded Successfully";
            }
            $connect->close();

		if ($psvid=="" ||  $routename==""  ) {
			echo "**All Fields Mandatory";
		}
		else {
			$query = "INSERT INTO `seat`(`PsvId`,`SeatNumber`, `availability`) VALUES('$psvid','$annArray', '$avail')";

			$bus_entry = mysqli_query($connection,$query);

			if (!$bus_entry) {
				die("Query Failed");
			}
			if($bus_entry) {
				echo '<p style="background-color:#66FFFF;">Bus added successfuly!</p>';
		
	
			}
		}
	}

?>