<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="style.css" />
    <title>seats selection</title>

    <style>
#seats{

    display: none;

}
</style>
    
</head>

<body>

<?php
  
       
$mysqli_hostname = "localhost";
$mysqli_user = "root";
$mysqli_password = "TV180RC";
$mysqli_database = "busreservation";
$prefix = "";
$connection = mysqli_connect($mysqli_hostname, $mysqli_user, $mysqli_password,$mysqli_database) or die("Could not connect database");
?>

<?php 

if (isset($_POST['submit-selection'])) {
	
		
		$price = $_POST['psvid'];
		$s1 = $_POST['s1'];
		$s2 = $_POST['s2'];
		$s3 = $_POST['s3'];
        $s4 = $_POST['s4'];
		$s5 = $_POST['s5'];
        $s6 = $_POST['s6'];
		$s7 = $_POST['s7'];
        $s8 = $_POST['s8'];
		$s9 = $_POST['s9'];
        $s10 = $_POST['s10'];
		$s11 = $_POST['s11'];
        $s12= $_POST['s12'];
		$s13= $_POST['s13'];
        $s14= $_POST['s14'];
		$s15= $_POST['s15'];
        $s16= $_POST['s16'];
		$s17= $_POST['s17'];
        $s18= $_POST['s18'];
		$s19= $_POST['s19'];
        $s20= $_POST['s20'];
		$s21= $_POST['s21'];
        $s22 = $_POST['s22'];
		$s23= $_POST['s23'];
        $s24 = $_POST['s24'];
		$s25 = $_POST['s25'];
        $s26 = $_POST['s26'];
		$s27 = $_POST['s27'];
        $s28 = $_POST['s28'];
		$s29 = $_POST['s29'];
        $s30 = $_POST['s30'];
		$s31 = $_POST['s31'];
        $s32 = $_POST['s32'];
		
		

	

		if ($s1=="" &&  $s2==""&&$s3=="" && $s4=="" &&  $s5==""&& $s6=="" &&  $s7==""&&$s8=="" && $s9=="" &&  $s10==""&& $s11=="" &&  $s12==""&&$s13=="" && $s14=="" &&  $s15==""&& $s16=="" &&  $s17==""&&$s18=="" && $s19=="" &&  $s20==""&& $s21=="" &&  $s22==""&&$s23=="" && $s24=="" &&  $s25==""&& $s26=="" &&  $s27==""&&$s28=="" && $s29=="" &&  $s30==""&& $s31=="" &&  $s32=="" ) {
			echo  '<p style="background-color:#66FFFF;">SELECT AT LEAST A SEAT!</p>';
		}
		else {
			$query = "INSERT INTO `seat`(`PsvId`, `s1`, `s2`, `s3`, `s4`, `s5`, `s6`, `s7`, `s8`, `s9`, `s10`, `s11`, `s12`, `s13`, `s14`, `s15`, `s16`, `s17`, `s18`, `s19`, `s20`, `s21`, `s22`, `s23`, `s24`, `s25`, `s26`, `s27`, `s28`, `s29`, `s30`, `s31`, `s32`) VALUES('$price', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7', '$s8', '$s9', '$s10', '$s11', '$s12', '$s13', '$s14', '$s15', '$s16', '$s17', '$s18', '$s19', '$s20', '$s21', '$s22', '$s23', '$s24', '$s25', '$s26', '$s27', '$s28', '$s29', '$s30', '$s31', '$s32')";

			$seat_save = mysqli_query($connection,$query);

			if (!$seat_save) {
				die("Query Failed");
			}
			if($seat_save) {
				echo '<p style="background-color:#66FFFF;">Bus added successfuly!</p>';
		}
	
			
		}
	}

?>
 <form method="post" action="">
    <div class="movie-container">
   
        <label >Select your preferred bus:</label>
        <select id="movie" name="psvid">
        <option value="1000">KDC 234C</option>
        <option value="1200">KBD 786F</option>
        <option value="800">KCH 735T</option>
        <option value="900">KBU 644Y</option>
      </select>
    
    </div>

    <ul class="showcase">
        <li>
            <div class="seat"></div>
            Available
        </li>
        <li>
            <div class="seat selected"></div>
            Selected
        </li>
        <li>
            <div class="seat occupied"></div>
            Booked
        </li>
    </ul>
    
    
        
    

    <div class="container">
        <div class="screen"></div>
        
        <div class="row">

        <label><input type="checkbox" name="s4" id="seats" value="4" /><div class="seat">4</div></label>
            <label><input type="checkbox" name="s3" id="seats" value="3" /><div class="seat">3</div></label>
            <label><input type="checkbox" name="s2" id="seats" value="2" /><div class="seat">2</div></label>
            <label><input type="checkbox" name="s1" id="seats" value="1" /><div class="seat occupied">1</div></label>


        </div>

        <div class="row">
<label><input type="checkbox" name="s8" id="seats" value="8" /><div class="seat">8</div></label>
<label><input type="checkbox" name="s7" id="seats" value="7" /><div class="seat">7</div></label>
<label><input type="checkbox" name="s6" id="seats" value="6" /><div class="seat">6</div></label>
<label> <input type="checkbox" name="s5" id="seats" value="5" /><div class="seat">5</div></label>

        </div>
        <div class="row">
        <label><input type="checkbox" name="s12" id="seats" value="12" /><div class="seat">12</div></label>
        <label><input type="checkbox" name="s11" id="seats" value="11" /><div class="seat">11</div></label>
        <label><input type="checkbox" name="s10" id="seats" value="10" /><div class="seat">10</div></label>
        <label><input type="checkbox" name="s9" id="seats" value="9" /><div class="seat occupied">9</div></label>

        </div>
        <div class="row">
        <label><input type="checkbox" name="s16" id="seats" value="16" /><div class="seat">16</div></label>
        <label><input type="checkbox" name="s15" id="seats" value="15" /><div class="seat">15</div></label>
        <label><input type="checkbox" name="s14" id="seats" value="14" /><div class="seat">14</div></label>
        <label><input type="checkbox" name="s13" id="seats" value="13" /><div class="seat">13</div></label>

        </div>
        <div class="row">
        <label><input type="checkbox" name="s20" id="seats" value="20" /><div class="seat">20</div></label>
        <label><input type="checkbox" name="s19" id="seats" value="19" /><div class="seat">19</div></label>
        <label><input type="checkbox" name="s18" id="seats" value="18" /><div class="seat">18</div></label>
        <label><input type="checkbox" name="s17" id="seats" value="17" /><div class="seat">17</div></label>

        </div>
        <div class="row">
        <label><input type="checkbox" name="s24" id="seats" value="24" /><div class="seat">24</div></label>
        <label><input type="checkbox" name="s23" id="seats" value="23" /><div class="seat">23</div></label>
        <label><input type="checkbox" name="s22" id="seats" value="22" /><div class="seat">22</div></label>
        <label><input type="checkbox" name="s21" id="seats" value="21" /><div class="seat occupied">21</div></label>

        </div>
        <div class="row">
        <label><input type="checkbox" name="s28" id="seats" value="28" /><div class="seat">28</div></label>
        <label><input type="checkbox" name="s27" id="seats" value="27" /><div class="seat">27</div></label>
        <label><input type="checkbox" name="s26" id="seats" value="26" /><div class="seat">26</div></label>
        <label><input type="checkbox" name="s25" id="seats" value="25" /><div class="seat">25</div></label>
        </div>
        <div class="row">
        <label><input type="checkbox" name="s32" id="seats" value="32" /><div class="seat">32</div></label>
        <label><input type="checkbox" name="s31" id="seats" value="31" /><div class="seat">31</div></label>
        <label><input type="checkbox" name="s30" id="seats" value="30" /><div class="seat">30</div></label>
        <label><input type="checkbox" name="s29" id="seats" value="29" /><div class="seat">29</div></label>
        </div>
        
    </div>
    
    <p class="text">
        You have selected <span id="count">0</span> seats for a price of Ksh. <span id="total">0</span
    >
  </p>
  <input type="submit" class="btn btn-primary" name="submit-selection" value="Submit">
  </form>
  <script src="script.js"></script>
</body>
</html>