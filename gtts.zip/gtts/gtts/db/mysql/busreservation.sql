-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: busreservation
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_credentials`
--

DROP TABLE IF EXISTS `admin_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_credentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(45) NOT NULL,
  `apassword` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_credentials`
--

LOCK TABLES `admin_credentials` WRITE;
/*!40000 ALTER TABLE `admin_credentials` DISABLE KEYS */;
INSERT INTO `admin_credentials` VALUES (2,'yy','yy@gmail.com','yy'),(3,'K','K','K'),(4,'s','s@gmail.com','s'),(5,'ss','ss@gmail.com','ss'),(7,'sw','sw@gmail.com','sw'),(9,'st','st@gmail.com','st'),(11,'sss','sss@gmail.com','s'),(13,'e','e@gmail.com','e'),(15,'sk','sk4@gmail.com','l'),(16,'q','skk@gmail.com','q'),(18,'kk','skk@gmail.com','kk'),(19,'aa','aa@gmail.com','aa'),(20,'b','skk@gmail.com','b'),(21,'kiokosk','ski@gmail.com','Qomon12/'),(22,'sdfgh','stevekioko866@gmail.com',''),(24,'admin','admin@gmail.com','Stephen1');
/*!40000 ALTER TABLE `admin_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `name` varchar(45) NOT NULL,
  `source` varchar(45) NOT NULL,
  `destination` varchar(45) NOT NULL,
  `TravelDate` date NOT NULL,
  `telephone` int NOT NULL,
  `PsvId` int NOT NULL,
  `SeatNumber` varchar(45) NOT NULL,
  `amount(ksh)` int NOT NULL,
  `PaymentStatus` varchar(45) NOT NULL,
  PRIMARY KEY (`telephone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES ('edwin','nairobi','eldoret','2021-12-21',79876453,2,'23',12,'unpaid'),('stephen','nairobi','eldoret','2021-12-21',711184869,1,'12',6000,'paid');
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passenger`
--

DROP TABLE IF EXISTS `passenger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passenger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `pickup` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `pdate` varchar(100) NOT NULL,
  `ptime` varchar(45) NOT NULL,
  `mins` varchar(45) NOT NULL,
  `det` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passenger`
--

LOCK TABLES `passenger` WRITE;
/*!40000 ALTER TABLE `passenger` DISABLE KEYS */;
INSERT INTO `passenger` VALUES (1,'QWERT','WEDC','SDFG','Mombasa','Nairobi','2022-02-08','1','05','AM'),(2,'SXDF','SZXDTJ','3456678','Nairobi','Mombasa','2022-02-23','1','05','AM'),(3,'wer','tr','078093','Eldoret','Nairobi','2022-02-07','1','05','AM'),(4,'wer','tr','078093','Eldoret','Nairobi','2022-02-07','1','05','AM'),(5,'tr','gh','5678788889','Nairobi','Mombasa','2022-02-07','1','05','AM'),(6,'edw','in','07678789','Nairobi','Nairobi','2022-02-07','1','05','AM'),(7,'edw','in','07678789','Nairobi','Nairobi','2022-02-07','1','05','AM'),(8,'stephen','k','5678788889','Nairobi','Mombasa','2022-02-07','3','30','PM'),(9,'ryu','yt','78775','Nairobi','Mombasa','2022-02-08','8','05','AM'),(10,'ryu','yt','78775','Nairobi','Mombasa','2022-02-08','8','05','AM'),(11,'stephen','re','078093','Nairobi','Mombasa','2022-02-07','1','05','AM'),(12,'stephen','sdfgh','5678788889','Nairobi','Mombasa','2022-02-07','1','05','AM'),(13,'stephen','sdfgh','078093','Nairobi','Eldoret','2022-02-08','1','05','AM'),(14,'wer','asd','778','Nairobi','Mombasa','2022-02-08','1','05','AM'),(15,'stephen','re','5678788889','Nairobi','Mombasa','2022-02-08','1','05','AM'),(16,'stephen','k','5678788889','Nairobi','Mombasa','2022-02-08','1','05','AM'),(17,'67','sdfgh','078093','Nairobi','Nairobi','2022-02-08','5','00','AM'),(18,'stephen','k','0713245670','Mombasa','Nairobi','2022-02-27','5','00','AM'),(19,'stephen','re','0713245670','Nairobi','Mombasa','2022-02-27','5','00','AM'),(20,'stephen','k','0712356789','Nairobi','Mombasa','2022-02-27','5','00','AM'),(21,'stephen','re','0713245670','Nairobi','Eldoret','2022-02-27','5','00','AM'),(22,'stephen','re','0713245670','Nairobi','Eldoret','2022-03-12','5','00','AM'),(23,'stephen','re','0713245670','Nairobi','Eldoret','2022-02-28','5','00','AM'),(24,'stephen','sdfgh','0713245670','Nairobi','Mombasa','2022-02-28','5','00','AM'),(25,'stephen','sdfgh','0713245670','Nairobi','Mombasa','2022-03-08','5','00','AM'),(26,'stephen','sdfgh','0713245670','Nairobi','Mombasa','2022-03-18','5','00','AM'),(27,'stephen','k','0713245670','Nairobi','Mombasa','2022-03-10','7','30','AM'),(28,'stephen','gh','0713245670','Mombasa','Nairobi','2022-03-31','5','00','AM'),(29,'stephen','re','0713245670','Nairobi','Mombasa','2022-03-04','5','00','AM'),(30,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-17','5','00','AM'),(31,'sk','kioko','34567890','Nairobi','Mombasa','2022-03-24','5','00','AM'),(32,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-23','5','00','AM'),(33,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-16','5','00','AM'),(34,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-09','5','00','AM'),(35,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-16','5','00','AM'),(36,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-22','5','00','AM'),(37,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-09','5','00','AM'),(38,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-24','5','00','AM'),(39,'st','st','234567','Nairobi','Mombasa','2022-03-30','5','00','AM'),(40,'stephen','kioko','0712345678','Nairobi','Eldoret','2022-03-24','5','00','AM'),(41,'stephen','kioko','0712345678','Nairobi','Eldoret','2022-03-24','5','00','AM'),(42,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-16','5','00','AM'),(43,'stephen','kioko','34567890','Nairobi','Mombasa','2022-03-16','5','00','AM'),(44,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-09','5','00','AM'),(45,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-09','5','00','AM'),(46,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-23','7','15','AM'),(47,'stephen','kioko','0712345678','Mombasa','Nairobi','2022-03-09','5','00','AM'),(48,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-16','5','00','AM'),(49,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-17','5','00','AM'),(50,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-17','5','00','AM'),(51,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-17','5','00','AM'),(52,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-10','5','00','AM'),(53,'stephen','omollo','0712345678','Nairobi','Mombasa','2022-03-29','5','00','AM'),(54,'stephen','sk','0712345678','Ksm','Mombasa','2022-03-23','5','00','AM'),(55,'stephen','sk','0712345678','Nairobi','Mombasa','2022-03-30','5','00','AM'),(56,'vbn','bnm','0712345678','Nairobi','Mombasa','2022-03-24','5','00','AM'),(57,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-03-24','5','00','AM'),(58,'Jacob','Eight','0718765432','Nairobi','Eldoret','2022-03-25','7','00','AM'),(59,'stephen','kioko','0711184869','Nairobi','Mombasa','2022-03-23','7','00','AM'),(60,'stephen','kioko','0712345678','Nairobi','Mombasa','2022-04-01','7','00','AM'),(61,'stephen','Eight','0712345678','Nairobi','Eldoret','2022-04-08','5','00','AM'),(62,'stephen','kioko','0712345678','Nairobi','Eldoret','2022-04-08','7','00','AM'),(63,'stephen','sk','0712345678','Nairobi','Mombasa','2022-04-08','7','00','AM');
/*!40000 ALTER TABLE `passenger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `CheckoutRequestID` varchar(500) DEFAULT NULL,
  `ResultCode` varchar(500) DEFAULT NULL,
  `amount` varchar(500) DEFAULT NULL,
  `MpesaReceiptNumber` varchar(500) DEFAULT NULL,
  `PhoneNumber` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES ('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','',''),('','','','','');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psv`
--

DROP TABLE IF EXISTS `psv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `psv` (
  `PsvId` int NOT NULL AUTO_INCREMENT,
  `PsvName` varchar(45) NOT NULL,
  `RouteName` varchar(75) NOT NULL,
  `capacity` int NOT NULL,
  `TDate` varchar(45) NOT NULL,
  `TravelTime` varchar(45) NOT NULL,
  `SeatCost` int NOT NULL,
  PRIMARY KEY (`PsvId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psv`
--

LOCK TABLES `psv` WRITE;
/*!40000 ALTER TABLE `psv` DISABLE KEYS */;
INSERT INTO `psv` VALUES (19,'KDG 104Q','Nairobi-Kitui-Momasa',32,'2022-03-09','12:45PM',1500),(20,'KDC 234C','Nairobi-Eldoret',33,'2022-03-11','12:45PM',1000),(21,'KCH 735T','Nairobi-Sultan Hamud- Mombasa',32,'2022-03-20','12:45PM',1200),(22,'KDC 104Q','Nairobi- Eldoret',30,'2022-04-08','14:26',1200);
/*!40000 ALTER TABLE `psv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routes` (
  `RouteId` int NOT NULL AUTO_INCREMENT,
  `RouteName` varchar(70) NOT NULL,
  `Source` varchar(45) NOT NULL,
  `Destination` varchar(45) NOT NULL,
  PRIMARY KEY (`RouteId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routes`
--

LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
INSERT INTO `routes` VALUES (2,'Nairobi-Sultan Hamud- Mombasa','Nairobi','Mombasa'),(3,'Nairobi- Eldoret','Nairobi','Eldoret'),(4,'Nairobi- Kitui- Mombasa','Nairobi','Mombasa');
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seat`
--

DROP TABLE IF EXISTS `seat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seat` (
  `PsvId` varchar(100) NOT NULL,
  `s1` int DEFAULT NULL,
  `s2` int DEFAULT NULL,
  `s3` int DEFAULT NULL,
  `s4` int DEFAULT NULL,
  `s5` int DEFAULT NULL,
  `s6` int DEFAULT NULL,
  `s7` int DEFAULT NULL,
  `s8` int DEFAULT NULL,
  `s9` int DEFAULT NULL,
  `s10` int DEFAULT NULL,
  `s11` int DEFAULT NULL,
  `s12` int DEFAULT NULL,
  `s13` int DEFAULT NULL,
  `s14` int DEFAULT NULL,
  `s15` int DEFAULT NULL,
  `s16` int DEFAULT NULL,
  `s17` int DEFAULT NULL,
  `s18` int DEFAULT NULL,
  `s19` int DEFAULT NULL,
  `s20` int DEFAULT NULL,
  `s21` int DEFAULT NULL,
  `s22` int DEFAULT NULL,
  `s23` int DEFAULT NULL,
  `s24` int DEFAULT NULL,
  `s25` int DEFAULT NULL,
  `s26` int DEFAULT NULL,
  `s27` int DEFAULT NULL,
  `s28` int DEFAULT NULL,
  `s29` int DEFAULT NULL,
  `s30` int DEFAULT NULL,
  `s31` int DEFAULT NULL,
  `s32` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seat`
--

LOCK TABLES `seat` WRITE;
/*!40000 ALTER TABLE `seat` DISABLE KEYS */;
INSERT INTO `seat` VALUES ('800',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('800',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32);
/*!40000 ALTER TABLE `seat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seats`
--

DROP TABLE IF EXISTS `seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seats` (
  `Price_per_seat_ksh` varchar(100) NOT NULL,
  `s1` int DEFAULT NULL,
  `s2` int DEFAULT NULL,
  `s3` int DEFAULT NULL,
  `s4` int DEFAULT NULL,
  `s5` int DEFAULT NULL,
  `s6` int DEFAULT NULL,
  `s7` int DEFAULT NULL,
  `s8` int DEFAULT NULL,
  `s9` int DEFAULT NULL,
  `s10` int DEFAULT NULL,
  `s11` int DEFAULT NULL,
  `s12` int DEFAULT NULL,
  `s13` int DEFAULT NULL,
  `s14` int DEFAULT NULL,
  `s15` int DEFAULT NULL,
  `s16` int DEFAULT NULL,
  `s17` int DEFAULT NULL,
  `s18` int DEFAULT NULL,
  `s19` int DEFAULT NULL,
  `s20` int DEFAULT NULL,
  `s21` int DEFAULT NULL,
  `s22` int DEFAULT NULL,
  `s23` int DEFAULT NULL,
  `s24` int DEFAULT NULL,
  `s25` int DEFAULT NULL,
  `s26` int DEFAULT NULL,
  `s27` int DEFAULT NULL,
  `s28` int DEFAULT NULL,
  `s29` int DEFAULT NULL,
  `s30` int DEFAULT NULL,
  `s31` int DEFAULT NULL,
  `s32` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seats`
--

LOCK TABLES `seats` WRITE;
/*!40000 ALTER TABLE `seats` DISABLE KEYS */;
INSERT INTO `seats` VALUES ('1200',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('1200',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('1200',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('900',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('900',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('900',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('900',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('900',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32),('900',1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32);
/*!40000 ALTER TABLE `seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tr`
--

DROP TABLE IF EXISTS `tr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tr` (
  `v1` varchar(150) DEFAULT NULL,
  `v2` varchar(150) DEFAULT NULL,
  `v3` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr`
--

LOCK TABLES `tr` WRITE;
/*!40000 ALTER TABLE `tr` DISABLE KEYS */;
INSERT INTO `tr` VALUES ('','',''),('Bike','',''),('','',''),('','',''),('','',''),('','',''),('','',''),('','',''),('','',''),('','',''),('','','');
/*!40000 ALTER TABLE `tr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt`
--

DROP TABLE IF EXISTS `tt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt` (
  `t1` varchar(100) DEFAULT NULL,
  `t2` varchar(100) DEFAULT NULL,
  `t3` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt`
--

LOCK TABLES `tt` WRITE;
/*!40000 ALTER TABLE `tt` DISABLE KEYS */;
INSERT INTO `tt` VALUES ('Bike','',''),('Bike','',''),('','Car','Boat'),('','Car','Boat'),('','Car','Boat'),('','Car','Boat'),('Bike','',''),('Bike','',''),('','Car',''),('','Car',''),('','Car',''),('','','Boat'),('','','Boat'),('Bike','Car','Boat'),('Bike','Car','Boat'),('','Car',''),('Bike','','');
/*!40000 ALTER TABLE `tt` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-13 22:29:35
