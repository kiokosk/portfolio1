-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Apr 13, 2022 at 09:12 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bus_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `name` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `pickup` varchar(255) NOT NULL,
  `destination` varchar(2555) NOT NULL,
  `tdate` varchar(255) NOT NULL,
  `ttime` varchar(255) NOT NULL,
  `b_id` varchar(100) NOT NULL,
  `snos` varchar(255) NOT NULL,
  `Price_per_seat_ksh` varchar(255) NOT NULL,
  `no` varchar(255) NOT NULL,
  `tcost` varchar(255) NOT NULL,
  `pstatus` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`name`, `telephone`, `pickup`, `destination`, `tdate`, `ttime`, `b_id`, `snos`, `Price_per_seat_ksh`, `no`, `tcost`, `pstatus`) VALUES
('stephen  sk', '0712345678', 'Nairobi', 'Mombasa', '2022-04-08', '7:00 AM', '7', '20', '1200', '1', '1200', 'Unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id` int(255) NOT NULL,
  `Price_per_seat_ksh` varchar(100) NOT NULL,
  `s1` int(11) DEFAULT NULL,
  `s2` int(11) DEFAULT NULL,
  `s3` int(11) DEFAULT NULL,
  `s4` int(11) DEFAULT NULL,
  `s5` int(11) DEFAULT NULL,
  `s6` int(11) DEFAULT NULL,
  `s7` int(11) DEFAULT NULL,
  `s8` int(11) DEFAULT NULL,
  `s9` int(11) DEFAULT NULL,
  `s10` int(11) DEFAULT NULL,
  `s11` int(11) DEFAULT NULL,
  `s12` int(11) DEFAULT NULL,
  `s13` int(11) DEFAULT NULL,
  `s14` int(11) DEFAULT NULL,
  `s15` int(11) DEFAULT NULL,
  `s16` int(11) DEFAULT NULL,
  `s17` int(11) DEFAULT NULL,
  `s18` int(11) DEFAULT NULL,
  `s19` int(11) DEFAULT NULL,
  `s20` int(11) DEFAULT NULL,
  `s21` int(11) DEFAULT NULL,
  `s22` int(11) DEFAULT NULL,
  `s23` int(11) DEFAULT NULL,
  `s24` int(11) DEFAULT NULL,
  `s25` int(11) DEFAULT NULL,
  `s26` int(11) DEFAULT NULL,
  `s27` int(11) DEFAULT NULL,
  `s28` int(11) DEFAULT NULL,
  `s29` int(11) DEFAULT NULL,
  `s30` int(11) DEFAULT NULL,
  `s31` int(11) DEFAULT NULL,
  `s32` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`id`, `Price_per_seat_ksh`, `s1`, `s2`, `s3`, `s4`, `s5`, `s6`, `s7`, `s8`, `s9`, `s10`, `s11`, `s12`, `s13`, `s14`, `s15`, `s16`, `s17`, `s18`, `s19`, `s20`, `s21`, `s22`, `s23`, `s24`, `s25`, `s26`, `s27`, `s28`, `s29`, `s30`, `s31`, `s32`) VALUES
(1, '', 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32),
(2, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, '1200', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
